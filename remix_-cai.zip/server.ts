import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Configure body parsing with a high limit to support base64 image attachments
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Lazy initialize Gemini AI client
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is not defined in the workspace secrets.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// 1. Keys Status Endpoint
app.get('/api/keys-status', (req, res) => {
  res.json({
    openai: !!process.env.OPENAI_API_KEY,
    anthropic: !!process.env.ANTHROPIC_API_KEY,
  });
});

// Helper: Run Gemini Stream
async function runGeminiStream(res: any, model: string, messages: any[], systemInstruction?: string, temperature?: number, maxTokens?: number) {
  const ai = getGeminiClient();
  const selectedModel = model || 'gemini-3.5-flash';

  const contents = messages.map((msg: any) => {
    const parts: any[] = [];
    if (msg.attachments && msg.attachments.length > 0) {
      msg.attachments.forEach((att: any) => {
        const base64Data = att.data.replace(/^data:[^;]+;base64,/, '');
        parts.push({
          inlineData: {
            data: base64Data,
            mimeType: att.type,
          },
        });
      });
    }
    parts.push({ text: msg.content || '' });
    const role = msg.role === 'assistant' ? 'model' : 'user';
    return { role, parts };
  });

  const responseStream = await ai.models.generateContentStream({
    model: selectedModel,
    contents,
    config: {
      systemInstruction: systemInstruction || undefined,
      temperature: typeof temperature === 'number' ? temperature : 0.7,
      maxOutputTokens: typeof maxTokens === 'number' ? maxTokens : 2048,
    },
  });

  for await (const chunk of responseStream) {
    const text = chunk.text || '';
    res.write(`data: ${JSON.stringify({ text })}\n\n`);
  }

  res.write('data: [DONE]\n\n');
  res.end();
}

// Helper: Run OpenAI Stream
async function runOpenAIStream(res: any, apiKey: string, model: string, messages: any[], systemInstruction?: string, temperature?: number, maxTokens?: number) {
  const formattedMessages: any[] = [];
  if (systemInstruction) {
    formattedMessages.push({ role: 'system', content: systemInstruction });
  }
  messages.forEach((msg: any) => {
    if (msg.role === 'system') return;
    formattedMessages.push({
      role: msg.role === 'assistant' ? 'assistant' : 'user',
      content: msg.content || '',
    });
  });

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: formattedMessages,
      temperature: typeof temperature === 'number' ? temperature : 0.7,
      max_tokens: typeof maxTokens === 'number' ? maxTokens : 2048,
      stream: true,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`OpenAI API returned status ${response.status}: ${errText}`);
  }

  const reader = response.body?.getReader();
  if (!reader) throw new Error('Failed to get OpenAI stream reader');

  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed === 'data: [DONE]') continue;
      if (trimmed.startsWith('data: ')) {
        try {
          const parsed = JSON.parse(trimmed.substring(6));
          const text = parsed.choices?.[0]?.delta?.content || '';
          if (text) {
            res.write(`data: ${JSON.stringify({ text })}\n\n`);
          }
        } catch (e) {
          // Ignore parse errors on incomplete chunks
        }
      }
    }
  }

  res.write('data: [DONE]\n\n');
  res.end();
}

// Helper: Run Anthropic Stream
async function runAnthropicStream(res: any, apiKey: string, model: string, messages: any[], systemInstruction?: string, temperature?: number, maxTokens?: number) {
  // Map internal name to Anthropic API model key
  let anthropicModel = 'claude-3-5-sonnet-20241022';
  if (model === 'claude-3-opus') {
    anthropicModel = 'claude-3-opus-20240229';
  }

  const formattedMessages: any[] = [];
  messages.forEach((msg: any) => {
    if (msg.role === 'system') return;
    formattedMessages.push({
      role: msg.role === 'assistant' ? 'assistant' : 'user',
      content: msg.content || '',
    });
  });

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: anthropicModel,
      system: systemInstruction || undefined,
      messages: formattedMessages,
      temperature: typeof temperature === 'number' ? Math.min(1.0, temperature) : 0.7,
      max_tokens: typeof maxTokens === 'number' ? maxTokens : 2048,
      stream: true,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Anthropic API returned status ${response.status}: ${errText}`);
  }

  const reader = response.body?.getReader();
  if (!reader) throw new Error('Failed to get Anthropic stream reader');

  const decoder = new TextDecoder('utf-8');
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      
      if (trimmed.startsWith('data: ')) {
        try {
          const parsed = JSON.parse(trimmed.substring(6));
          if (parsed.type === 'content_block_delta') {
            const text = parsed.delta?.text || '';
            if (text) {
              res.write(`data: ${JSON.stringify({ text })}\n\n`);
            }
          }
        } catch (e) {
          // Ignore parse errors on incomplete chunks
        }
      }
    }
  }

  res.write('data: [DONE]\n\n');
  res.end();
}

// 2. Streaming Chat API Endpoint
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, systemInstruction, temperature, maxTokens, model } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required.' });
    }

    const selectedModel = model || 'gemini-3.5-flash';

    // Set up headers for Server-Sent Events (SSE) streaming
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    // Route to appropriate model handler
    if (selectedModel.startsWith('gpt-')) {
      const openaiApiKey = process.env.OPENAI_API_KEY;
      if (!openaiApiKey) {
        const simulationInstruction = `${systemInstruction || ''}\n\n[SANDBOX SIMULATION MODE]: You are simulating a GPT-4 model (${selectedModel}) from OpenAI. Respond in a highly precise, helpful, and logical tone, identifying yourself as GPT-4. Add a subtle notice in your greeting if appropriate, but otherwise fulfill the prompt exactly as a professional GPT-4 model would. (Reason: OPENAI_API_KEY is not defined in workspace Secrets).`;
        return runGeminiStream(res, 'gemini-3.5-flash', messages, simulationInstruction, temperature, maxTokens);
      }
      return runOpenAIStream(res, openaiApiKey, selectedModel, messages, systemInstruction, temperature, maxTokens);
    }

    if (selectedModel.startsWith('claude-')) {
      const anthropicApiKey = process.env.ANTHROPIC_API_KEY;
      if (!anthropicApiKey) {
        const simulationInstruction = `${systemInstruction || ''}\n\n[SANDBOX SIMULATION MODE]: You are simulating a Claude model (${selectedModel}) from Anthropic. Respond in a highly articulate, warm, deeply detailed, and well-structured formatting style, identifying yourself as Claude. (Reason: ANTHROPIC_API_KEY is not defined in workspace Secrets).`;
        return runGeminiStream(res, 'gemini-3.5-flash', messages, simulationInstruction, temperature, maxTokens);
      }
      return runAnthropicStream(res, anthropicApiKey, selectedModel, messages, systemInstruction, temperature, maxTokens);
    }

    // Default: Gemini
    return runGeminiStream(res, selectedModel, messages, systemInstruction, temperature, maxTokens);

  } catch (error: any) {
    console.error('Error in /api/chat stream:', error);
    // If headers already sent, write the error into the stream
    if (res.headersSent) {
      res.write(`data: ${JSON.stringify({ error: error.message || 'Streaming failed' })}\n\n`);
      res.end();
    } else {
      res.status(500).json({ error: error.message || 'Internal server error during streaming' });
    }
  }
});

// 2. Prompt Enhancer API Endpoint
app.post('/api/enhance-prompt', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Prompt text is required.' });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are a master Prompt Engineer specializing in creating world-class, structured LLM prompts.
Your job is to take the user's raw prompt and rewrite it using top-tier prompt engineering structures (such as Role, Context, Task, Constraints, and Output Format).
Provide ONLY the final enhanced prompt in markdown format, designed to be copy-pasted or fed directly into an AI model.
Do not write any introductory pleasantries, explanations, or conclusions. Start directly with the enhanced prompt.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Please optimize and engineer this raw prompt:\n"${prompt}"`,
      config: {
        systemInstruction,
        temperature: 0.5,
      },
    });

    res.json({ enhancedPrompt: response.text });
  } catch (error: any) {
    console.error('Error in /api/enhance-prompt:', error);
    res.status(500).json({ error: error.message || 'Failed to enhance prompt' });
  }
});

// 3. Summarization API Endpoint
app.post('/api/summarize', async (req, res) => {
  try {
    const { content } = req.body;
    if (!content || typeof content !== 'string') {
      return res.status(400).json({ error: 'Text content to summarize is required.' });
    }

    const ai = getGeminiClient();

    const systemInstruction = `You are an expert summaries generator. Your task is to summarize the provided text down into exactly one short, clean, and cohesive paragraph (maximum 3-4 sentences). Do not add any conversational preambles, intros, or postambles. Just return the summarized paragraph directly.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: `Please summarize the following content down into a single short paragraph:\n\n"${content}"`,
      config: {
        systemInstruction,
        temperature: 0.3,
      },
    });

    res.json({ summary: response.text });
  } catch (error: any) {
    console.error('Error in /api/summarize:', error);
    res.status(500).json({ error: error.message || 'Failed to summarize content' });
  }
});

// Initialize Vite and start listening
async function startServer() {
  // Vite dev server middleware integration in non-production environments
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files from compiled dist folder in production
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[CAI Server] Running at http://localhost:${PORT} under ${process.env.NODE_ENV || 'development'} mode`);
  });
}

startServer();
