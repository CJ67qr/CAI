export interface Attachment {
  name: string;
  type: string;
  data: string; // base64 encoded string
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  modelUsed?: string;
  attachments?: Attachment[];
  isEnhanced?: boolean;
  cost?: number; // Cost of this transaction in USD
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  systemPromptId: string; // references custom system instructions
  temperature: number;
  maxTokens: number;
  model: string;
  createdAt: number;
  updatedAt: number;
}

export interface SystemPrompt {
  id: string;
  name: string;
  description: string;
  prompt: string;
  icon: string; // Lucide icon name
}

export interface PromptTemplate {
  id: string;
  category: 'coding' | 'writing' | 'marketing' | 'learning' | 'general';
  name: string;
  description: string;
  template: string;
  variables: string[];
  icon: string;
}

export interface ModelConfig {
  temperature: number;
  maxTokens: number;
  model: string;
}
