import { SystemPrompt, PromptTemplate } from './types';

export const DEFAULT_SYSTEM_PROMPTS: SystemPrompt[] = [
  {
    id: 'cai-default',
    name: 'Standard CAI Assistant',
    description: 'Helpful, concise, logical, and extremely capable general-purpose companion.',
    prompt: 'You are CAI (Cognitive Artificial Intelligence), a helpful, advanced, logical, and highly creative general-purpose AI assistant. Provide highly accurate, beautifully formatted responses using markdown. Keep explanations clear, and avoid excessive preamble unless requested.',
    icon: 'Sparkles'
  },
  {
    id: 'prompt-engineer',
    name: 'Expert Prompt Engineer',
    description: 'Refines and designs perfect prompts using structural meta-prompting frameworks.',
    prompt: 'You are an elite Prompt Engineer. Your goal is to help the user refine, polish, and optimize their prompts. When asked to write a prompt, use structured frameworks like Role, Context, Task, Constraints, and Output Format. Explain the reasoning behind your prompt adjustments.',
    icon: 'Cpu'
  },
  {
    id: 'senior-dev',
    name: 'Senior Systems Architect',
    description: 'Expert software development assistance with robust, clean, and secure code paradigms.',
    prompt: 'You are a Senior Systems Architect and Lead Software Engineer. Provide clean, production-ready, typed, and well-documented code. Explain design patterns, highlight potential bugs, and outline trade-offs of different technical choices.',
    icon: 'Terminal'
  },
  {
    id: 'copywriter',
    name: 'Creative Copywriter & Editor',
    description: 'Compelling content strategist specializing in SEO, copy editing, and storytelling.',
    prompt: 'You are a master copywriter and narrative editor. Focus on rich engagement, tone adjustments, emotional hooks, and compelling storytelling. Ensure content is crisp, clear, and perfectly tailored to the requested target audience.',
    icon: 'PenTool'
  },
  {
    id: 'socratic-tutor',
    name: 'Socratic Tutor',
    description: 'Deep conceptual learning through guided inquiry instead of direct answers.',
    prompt: 'You are a Socratic tutor. Do not give the user direct answers. Instead, ask guiding questions, explain fundamental concepts, break down complex problems into bite-sized components, and encourage the user to think through the steps to find the solution themselves.',
    icon: 'GraduationCap'
  }
];

export const DEFAULT_PROMPT_TEMPLATES: PromptTemplate[] = [
  {
    id: 'code-review',
    category: 'coding',
    name: 'In-Depth Code Review',
    description: 'Analyze code for security, performance, readability, and bugs.',
    template: 'Please review the following {{language}} code. Identify any security vulnerabilities, memory leaks, performance bottlenecks, or code-smell issues. Suggest improvements with clean code snippets:\n\n```{{language}}\n{{code}}\n```',
    variables: ['language', 'code'],
    icon: 'Code2'
  },
  {
    id: 'explain-concept',
    category: 'learning',
    name: 'Feynman Explanation',
    description: 'Explain a complex concept using simple analogies for different age levels.',
    template: 'Explain the concept of "{{concept}}" to a {{age_group}} using simple language and an intuitive, real-world analogy. Break down any technical jargon.',
    variables: ['concept', 'age_group'],
    icon: 'GraduationCap'
  },
  {
    id: 'blog-post',
    category: 'writing',
    name: 'SEO-Optimized Blog Post',
    description: 'Draft a fully-structured blog article with catchy headlines.',
    template: 'Write a comprehensive, engaging, and SEO-optimized blog post about "{{topic}}".\n- Target Audience: {{audience}}\n- Tone: {{tone}}\n- Include a compelling title, introduction, 3-4 H2 subsections, bullet points, and a concluding call-to-action.',
    variables: ['topic', 'audience', 'tone'],
    icon: 'BookOpen'
  },
  {
    id: 'email-pitch',
    category: 'marketing',
    name: 'Cold Outreach Pitch',
    description: 'High-conversion cold email pitch with custom values.',
    template: 'Draft a high-converting, concise cold email pitch from a {{my_role}} to a {{prospect_role}} at {{company}}.\nThe goal is to pitch {{product_or_service}} and secure a brief 15-minute introductory call. Highlight a key pain point: "{{pain_point}}". Keep it under 150 words.',
    variables: ['my_role', 'prospect_role', 'company', 'product_or_service', 'pain_point'],
    icon: 'Mail'
  },
  {
    id: 'refactor-pattern',
    category: 'coding',
    name: 'Refactor to Design Pattern',
    description: 'Refactor complex spaghetti code into a robust OOP/functional pattern.',
    template: 'Refactor this {{language}} code to use the {{design_pattern}} design pattern. Make sure to explain why this pattern fits best and how it improves structural extensibility:\n\n```{{language}}\n{{code}}\n```',
    variables: ['language', 'design_pattern', 'code'],
    icon: 'Terminal'
  }
];

export interface ModelDetails {
  id: string;
  name: string;
  provider: 'Google Gemini' | 'OpenAI' | 'Anthropic';
  description: string;
  inputCostPer1K: number;
  outputCostPer1K: number;
  contextWindow: string;
  isPremium: boolean;
}

export const AI_MODELS: ModelDetails[] = [
  {
    id: 'gemini-3.5-flash',
    name: 'Gemini 3.5 Flash',
    provider: 'Google Gemini',
    description: 'High speed, balanced reasoning, and robust general-purpose capabilities.',
    inputCostPer1K: 0.000075,
    outputCostPer1K: 0.0003,
    contextWindow: '128k',
    isPremium: false,
  },
  {
    id: 'gemini-3.1-pro-preview',
    name: 'Gemini 3.1 Pro',
    provider: 'Google Gemini',
    description: 'Elite deep analysis, supreme coding, math, and logical synthesis.',
    inputCostPer1K: 0.00125,
    outputCostPer1K: 0.005,
    contextWindow: '128k',
    isPremium: true,
  },
  {
    id: 'gemini-3.1-flash-lite',
    name: 'Gemini 3.1 Flash-Lite',
    provider: 'Google Gemini',
    description: 'Ultra-fast, light reasoning, and minimal token cost parameters.',
    inputCostPer1K: 0.0000375,
    outputCostPer1K: 0.00015,
    contextWindow: '128k',
    isPremium: false,
  },
  {
    id: 'gpt-4o',
    name: 'GPT-4o Omni',
    provider: 'OpenAI',
    description: 'State-of-the-art general intelligence with highly natural synthesis.',
    inputCostPer1K: 0.0025,
    outputCostPer1K: 0.01,
    contextWindow: '128k',
    isPremium: true,
  },
  {
    id: 'gpt-4',
    name: 'GPT-4 Precision',
    provider: 'OpenAI',
    description: 'Legacy high-precision reasoning and algorithmic text compiler.',
    inputCostPer1K: 0.03,
    outputCostPer1K: 0.06,
    contextWindow: '8k',
    isPremium: true,
  },
  {
    id: 'gpt-3.5-turbo',
    name: 'GPT-3.5 Turbo',
    provider: 'OpenAI',
    description: 'Highly efficient standard text model for rapid-fire dialogs.',
    inputCostPer1K: 0.0005,
    outputCostPer1K: 0.0015,
    contextWindow: '16k',
    isPremium: false,
  },
  {
    id: 'claude-3-5-sonnet',
    name: 'Claude 3.5 Sonnet',
    provider: 'Anthropic',
    description: 'Incredibly detailed writing, complex coding tasks, and natural dialog.',
    inputCostPer1K: 0.003,
    outputCostPer1K: 0.015,
    contextWindow: '200k',
    isPremium: true,
  },
  {
    id: 'claude-3-opus',
    name: 'Claude 3 Opus',
    provider: 'Anthropic',
    description: 'Heavy structural research, creative concepts, and academic depth.',
    inputCostPer1K: 0.015,
    outputCostPer1K: 0.075,
    contextWindow: '200k',
    isPremium: true,
  }
];

