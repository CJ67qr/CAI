import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  Cpu,
  Terminal,
  PenTool,
  GraduationCap,
  Plus,
  MessageSquare,
  Send,
  Image as ImageIcon,
  Paperclip,
  Wrench,
  Trash2,
  HelpCircle,
  Code2,
  BookOpen,
  Mail,
  Maximize2,
  Minimize2,
  Settings,
  User,
  Activity,
  Layers,
  ArrowRight,
  ChevronRight,
  Info,
  X,
  Check,
  AlertTriangle,
  Github,
  Menu
} from 'lucide-react';
import { Message, ChatSession, Attachment, ModelConfig, PromptTemplate } from './types';
import { DEFAULT_SYSTEM_PROMPTS, DEFAULT_PROMPT_TEMPLATES, AI_MODELS } from './data';
import ChatSidebar from './components/ChatSidebar';
import PromptEngineeringTools from './components/PromptEngineeringTools';
import MarkdownRenderer from './components/MarkdownRenderer';

export default function App() {
  // --- Persistent Storage Key Definitions ---
  const STORAGE_SESSIONS_KEY = 'cai_chat_sessions';
  const STORAGE_CONFIG_KEY = 'cai_model_config';
  const STORAGE_ACTIVE_PROMPT_KEY = 'cai_active_system_prompt_id';
  const STORAGE_CUSTOM_SYSTEM_KEY = 'cai_custom_system_prompt';
  const STORAGE_WALLET_BALANCE_KEY = 'cai_wallet_balance';
  const STORAGE_PAYMENT_METHOD_KEY = 'cai_payment_method';
  const STORAGE_BILLING_PRIORITY_KEY = 'cai_billing_priority';

  // --- Core States ---
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [inputMessage, setInputMessage] = useState('');
  
  // Model Settings
  const [modelConfig, setModelConfig] = useState<ModelConfig>({
    temperature: 0.7,
    maxTokens: 2048,
    model: 'gemini-3.5-flash',
  });

  // Billing and Payment States
  const [walletBalance, setWalletBalance] = useState<number>(25.00);
  const [paymentMethod, setPaymentMethod] = useState<'credits' | 'card' | 'subscription'>('credits');
  const [billingPriority, setBillingPriority] = useState<'eco' | 'standard' | 'priority'>('standard');
  const [keysStatus, setKeysStatus] = useState<{ openai: boolean; anthropic: boolean }>({ openai: false, anthropic: false });

  // Persona / System Prompt States
  const [activeSystemPromptId, setActiveSystemPromptId] = useState<string>('cai-default');
  const [customSystemPrompt, setCustomSystemPrompt] = useState<string>(
    DEFAULT_SYSTEM_PROMPTS.find(p => p.id === 'cai-default')?.prompt || ''
  );

  // Layout / View Utilities
  const [isLeftSidebarOpen, setIsLeftSidebarOpen] = useState(false);
  const [isRightSuiteOpen, setIsRightSuiteOpen] = useState(false);
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<PromptTemplate | null>(null);
  const [templateVariables, setTemplateVariables] = useState<Record<string, string>>({});
  
  // Attachments State
  const [uploadedAttachments, setUploadedAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  
  // SSE Streaming State
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedText, setStreamedText] = useState('');

  // Summarization States
  const [messageSummaries, setMessageSummaries] = useState<Record<string, { text: string; loading: boolean; isViewingSummary: boolean }>>({});
  const [sessionSummaries, setSessionSummaries] = useState<Record<string, { text: string; loading: boolean; isOpen: boolean }>>({});

  const chatEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Initial Mount & Recovery from LocalStorage ---
  useEffect(() => {
    // 1. Recover Chat Sessions
    const savedSessions = localStorage.getItem(STORAGE_SESSIONS_KEY);
    if (savedSessions) {
      try {
        const parsed = JSON.parse(savedSessions);
        setSessions(parsed);
        if (parsed.length > 0) {
          setActiveSessionId(parsed[0].id);
        }
      } catch (err) {
        console.error('Failed to parse saved sessions from localStorage:', err);
      }
    } else {
      // Create first chat session if empty
      const initialSession: ChatSession = {
        id: 'initial-session-id',
        title: 'Quantum Physics Simulation',
        messages: [
          {
            id: 'm1',
            role: 'user',
            content: 'Explain the concept of recursive self-improvement in large language models and how we can apply prompt engineering to stabilize its output.',
            timestamp: Date.now() - 120000,
          },
          {
            id: 'm2',
            role: 'assistant',
            content: `Recursive self-improvement refers to the process where an agent optimizes its own architecture to enhance its capability. In the context of **CAI-Lumina**, this is simulated through multi-stage reflection.\n\n### Core Stabilization Framework:\n1. **Boundary Constraints**: Define strict operational bounds for mathematical calculations and logical inference steps.\n2. **Entropy Control**: Restrict temperature thresholds dynamically across recursive reflection loops.\n3. **Structured Schemas**: Enforce output compilation formats (e.g. typed JSON structure validations) to prevent linguistic drift.\n\nHere is a simple conceptual implementation of an iterative self-improvement stabilizer written in typescript:\n\n\`\`\`typescript\ninterface OptimizationState {\n  prompt: string;\n  iteration: number;\n  entropy: number;\n}\n\nfunction stabilizeOutput(state: OptimizationState): string {\n  if (state.iteration >= 5) {\n    return "Maximum recursion depth reached securely.";\n  }\n  // Limit dynamic exploration based on iterative cooling\n  const targetTemp = Math.max(0.1, 0.82 - (state.iteration * 0.15));\n  return \`Recursion loop \${state.iteration} running safely under temperature \${targetTemp.toFixed(2)}\`;\n}\n\`\`\``,
            timestamp: Date.now() - 60000,
            modelUsed: 'gemini-3.5-flash',
            isEnhanced: true,
          }
        ],
        systemPromptId: 'cai-default',
        temperature: 0.7,
        maxTokens: 2048,
        model: 'gemini-3.5-flash',
        createdAt: Date.now() - 120000,
        updatedAt: Date.now() - 60000,
      };
      setSessions([initialSession]);
      setActiveSessionId(initialSession.id);
    }

    // 2. Recover Config
    const savedConfig = localStorage.getItem(STORAGE_CONFIG_KEY);
    if (savedConfig) {
      try {
        setModelConfig(JSON.parse(savedConfig));
      } catch (err) {
        console.error('Failed to recover model config:', err);
      }
    }

    // 3. Recover System Prompts
    const savedActivePrompt = localStorage.getItem(STORAGE_ACTIVE_PROMPT_KEY);
    const savedCustomPrompt = localStorage.getItem(STORAGE_CUSTOM_SYSTEM_KEY);
    if (savedActivePrompt) setActiveSystemPromptId(savedActivePrompt);
    if (savedCustomPrompt) setCustomSystemPrompt(savedCustomPrompt);

    // 4. Recover Billing & Wallet Settings
    const savedBalance = localStorage.getItem(STORAGE_WALLET_BALANCE_KEY);
    const savedMethod = localStorage.getItem(STORAGE_PAYMENT_METHOD_KEY);
    const savedPriority = localStorage.getItem(STORAGE_BILLING_PRIORITY_KEY);
    if (savedBalance !== null) setWalletBalance(parseFloat(savedBalance));
    if (savedMethod !== null) setPaymentMethod(savedMethod as any);
    if (savedPriority !== null) setBillingPriority(savedPriority as any);

    // 5. Query API Keys Status from Server Environment
    fetch('/api/keys-status')
      .then(res => res.json())
      .then(data => {
        setKeysStatus({
          openai: !!data.openai,
          anthropic: !!data.anthropic
        });
      })
      .catch(err => console.error('Failed to query API keys status:', err));

    // 6. Responsive Viewport Defaults
    if (window.innerWidth >= 1024) {
      setIsRightSuiteOpen(true);
    } else {
      setIsRightSuiteOpen(false);
    }
  }, []);

  // --- Save to LocalStorage on changes ---
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem(STORAGE_SESSIONS_KEY, JSON.stringify(sessions));
    }
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(modelConfig));
  }, [modelConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_ACTIVE_PROMPT_KEY, activeSystemPromptId);
  }, [activeSystemPromptId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_CUSTOM_SYSTEM_KEY, customSystemPrompt);
  }, [customSystemPrompt]);

  useEffect(() => {
    localStorage.setItem(STORAGE_WALLET_BALANCE_KEY, walletBalance.toString());
  }, [walletBalance]);

  useEffect(() => {
    localStorage.setItem(STORAGE_PAYMENT_METHOD_KEY, paymentMethod);
  }, [paymentMethod]);

  useEffect(() => {
    localStorage.setItem(STORAGE_BILLING_PRIORITY_KEY, billingPriority);
  }, [billingPriority]);

  // Scroll to bottom on new messages
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sessions, activeSessionId, streamedText]);

  // Find the currently active session
  const activeSession = sessions.find(s => s.id === activeSessionId) || null;

  // Sync System Prompt when user selects a preset
  const handleSelectSystemPrompt = (id: string) => {
    setActiveSystemPromptId(id);
    const preset = DEFAULT_SYSTEM_PROMPTS.find(p => p.id === id);
    if (preset) {
      setCustomSystemPrompt(preset.prompt);
    }
  };

  // --- Chat Actions ---

  // Create new conversation thread
  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: `chat-${Date.now()}`,
      title: 'New Conversation Thread',
      messages: [],
      systemPromptId: activeSystemPromptId,
      temperature: modelConfig.temperature,
      maxTokens: modelConfig.maxTokens,
      model: modelConfig.model,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    setSessions([newSession, ...sessions]);
    setActiveSessionId(newSession.id);
  };

  // Delete a thread
  const handleDeleteSession = (id: string) => {
    const updated = sessions.filter(s => s.id !== id);
    setSessions(updated);
    if (activeSessionId === id) {
      if (updated.length > 0) {
        setActiveSessionId(updated[0].id);
      } else {
        setActiveSessionId(null);
      }
    }
  };

  // Rename thread title
  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions(prev =>
      prev.map(s => (s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s))
    );
  };

  // Clear all chats
  const handleClearAllSessions = () => {
    setSessions([]);
    setActiveSessionId(null);
  };

  // --- Attachments Handling ---
  const processFiles = (files: FileList) => {
    Array.from(files).forEach((file) => {
      if (!file.type.startsWith('image/')) {
        alert('Please upload only images for compatibility with the Gemini multimodal suite.');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          const newAttachment: Attachment = {
            name: file.name,
            type: file.type,
            data: e.target.result as string,
          };
          setUploadedAttachments(prev => [...prev, newAttachment]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileSelectChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      processFiles(e.target.files);
    }
  };

  const removeAttachment = (index: number) => {
    setUploadedAttachments(prev => prev.filter((_, i) => i !== index));
  };

  // --- Calculate Cost for Model Transactions ---
  const calculateCost = (promptLength: number, replyLength: number, modelId: string) => {
    const model = AI_MODELS.find(m => m.id === modelId) || AI_MODELS[0];
    
    // Multipliers for priority/eco billing
    let multiplier = 1.0;
    if (billingPriority === 'priority') multiplier = 1.25;
    if (billingPriority === 'eco') multiplier = 0.85;

    // Subscriptions: standard models are $0. Premium models get a 50% discount.
    if (paymentMethod === 'subscription') {
      if (!model.isPremium) return 0.0;
      multiplier *= 0.5;
    }

    const promptTokens = Math.max(20, Math.ceil(promptLength / 4.0)) + 120;
    const completionTokens = Math.max(10, Math.ceil(replyLength / 4.0));

    const inputCost = (promptTokens / 1000) * model.inputCostPer1K;
    const outputCost = (completionTokens / 1000) * model.outputCostPer1K;

    let baseCost = (inputCost + outputCost) * multiplier;
    
    // Add priority static speed surcharge
    if (billingPriority === 'priority') {
      baseCost += 0.001;
    }

    return parseFloat(baseCost.toFixed(6));
  };

  // --- Summarize Message Helper ---
  const handleSummarizeMessage = async (msgId: string, content: string) => {
    if (messageSummaries[msgId]?.text) {
      setMessageSummaries(prev => ({
        ...prev,
        [msgId]: {
          ...prev[msgId],
          isViewingSummary: !prev[msgId].isViewingSummary
        }
      }));
      return;
    }

    setMessageSummaries(prev => ({
      ...prev,
      [msgId]: {
        text: '',
        loading: true,
        isViewingSummary: true
      }
    }));

    try {
      const response = await fetch('/api/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content }),
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setMessageSummaries(prev => ({
        ...prev,
        [msgId]: {
          text: data.summary || 'Failed to generate summary.',
          loading: false,
          isViewingSummary: true
        }
      }));
    } catch (err: any) {
      console.error(err);
      setMessageSummaries(prev => ({
        ...prev,
        [msgId]: {
          text: 'Error generating summary. Please try again.',
          loading: false,
          isViewingSummary: true
        }
      }));
    }
  };

  // --- Summarize Session (Conversation Thread) Helper ---
  const handleSummarizeSession = async () => {
    if (!activeSessionId) return;
    const activeSession = sessions.find(s => s.id === activeSessionId);
    if (!activeSession || activeSession.messages.length === 0) return;

    if (sessionSummaries[activeSessionId]?.text) {
      setSessionSummaries(prev => ({
        ...prev,
        [activeSessionId]: {
          ...prev[activeSessionId],
          isOpen: !prev[activeSessionId].isOpen
        }
      }));
      return;
    }

    setSessionSummaries(prev => ({
      ...prev,
      [activeSessionId]: {
        text: '',
        loading: true,
        isOpen: true
      }
    }));

    const conversationText = activeSession.messages
      .filter(m => m.role === 'user' || m.role === 'assistant')
      .map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`)
      .join('\n\n');

    try {
      const response = await fetch('/api/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: conversationText }),
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error);

      setSessionSummaries(prev => ({
        ...prev,
        [activeSessionId]: {
          text: data.summary || 'Failed to generate summary.',
          loading: false,
          isOpen: true
        }
      }));
    } catch (err: any) {
      console.error(err);
      setSessionSummaries(prev => ({
        ...prev,
        [activeSessionId]: {
          text: 'Error compiling conversation summary. Please try again.',
          loading: false,
          isOpen: true
        }
      }));
    }
  };

  // --- Stream message submission to backend API ---
  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend !== undefined ? textToSend : inputMessage).trim();
    if (!text && uploadedAttachments.length === 0) return;
    if (!activeSessionId) return;

    // Validate wallet balance if paying with credits
    if (paymentMethod === 'credits' && walletBalance <= 0) {
      const balanceWarningMsg: Message = {
        id: `msg-bal-warn-${Date.now()}`,
        role: 'system',
        content: `ALERT: Your Cognitive Credit Balance is $0.00. Please refill your wallet or change your billing settings in the Models & Billing panel in the right sidebar to resume communicating.`,
        timestamp: Date.now(),
      };
      setSessions(prev =>
        prev.map(s => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: [...s.messages, balanceWarningMsg],
              updatedAt: Date.now(),
            };
          }
          return s;
        })
      );
      return;
    }

    // Build the user message object
    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
      attachments: uploadedAttachments.length > 0 ? uploadedAttachments : undefined,
    };

    // Update active thread with user message immediately
    let updatedMessages = [...(activeSession?.messages || []), userMsg];
    
    // Auto-update thread title if it was default
    let updatedTitle = activeSession?.title || 'New Conversation Thread';
    if (updatedMessages.length === 1) {
      updatedTitle = text.length > 30 ? text.substring(0, 30) + '...' : text;
    }

    setSessions(prev =>
      prev.map(s => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            title: updatedTitle,
            messages: updatedMessages,
            updatedAt: Date.now(),
          };
        }
        return s;
      })
    );

    // Clear input panel
    setInputMessage('');
    setUploadedAttachments([]);

    // Initialize Streaming Mode
    setIsStreaming(true);
    setStreamedText('');

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages,
          systemInstruction: customSystemPrompt,
          temperature: modelConfig.temperature,
          maxTokens: modelConfig.maxTokens,
          model: modelConfig.model,
        }),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`);
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder('utf-8');
      if (!reader) throw new Error('Response stream reader is undefined.');

      let accumulatedAnswer = '';
      let done = false;

      while (!done) {
        const { value, done: readerDone } = await reader.read();
        done = readerDone;
        if (value) {
          const chunkStr = decoder.decode(value, { stream: true });
          // Split chunk by SSE lines "data: { ... }"
          const lines = chunkStr.split('\n');
          for (const line of lines) {
            const trimmedLine = line.trim();
            if (!trimmedLine || !trimmedLine.startsWith('data: ')) continue;
            
            const rawData = trimmedLine.substring(6);
            if (rawData === '[DONE]') {
              done = true;
              break;
            }

            try {
              const parsed = JSON.parse(rawData);
              if (parsed.error) {
                throw new Error(parsed.error);
              }
              if (parsed.text) {
                accumulatedAnswer += parsed.text;
                setStreamedText(accumulatedAnswer);
              }
            } catch (err) {
              // Ignore occasional parsing issues with partial frames
            }
          }
        }
      }

      // Calculate transaction cost and deduct
      const userContentLength = text.length;
      const assistantContentLength = accumulatedAnswer.length;
      const transactionCost = calculateCost(userContentLength, assistantContentLength, modelConfig.model);

      if (paymentMethod === 'credits') {
        setWalletBalance(prev => Math.max(0.0, prev - transactionCost));
      }

      // Add final stream output to session message array
      const assistantMsg: Message = {
        id: `msg-resp-${Date.now()}`,
        role: 'assistant',
        content: accumulatedAnswer || 'No response compiled by the AI engine.',
        timestamp: Date.now(),
        modelUsed: modelConfig.model,
        cost: transactionCost,
      };

      setSessions(prev =>
        prev.map(s => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: [...s.messages, assistantMsg],
              updatedAt: Date.now(),
            };
          }
          return s;
        })
      );
    } catch (err: any) {
      console.error(err);
      // Inject system-level error message
      const errMsg: Message = {
        id: `msg-err-${Date.now()}`,
        role: 'system',
        content: `Error: ${err.message || 'The server context failed to stream a response.'} Make sure your GEMINI_API_KEY is configured in the AI Studio Secrets menu.`,
        timestamp: Date.now(),
      };

      setSessions(prev =>
        prev.map(s => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: [...s.messages, errMsg],
              updatedAt: Date.now(),
            };
          }
          return s;
        })
      );
    } finally {
      setIsStreaming(false);
      setStreamedText('');
    }
  };

  // Loaded from prompt suite directly
  const handleLoadEnhancedPrompt = (promptText: string) => {
    setInputMessage(promptText);
    setIsTemplateModalOpen(false);
  };

  // --- Prompt Template Helpers ---
  const openTemplateModal = (template: PromptTemplate) => {
    setSelectedTemplate(template);
    const initialVars: Record<string, string> = {};
    template.variables.forEach(v => {
      initialVars[v] = '';
    });
    setTemplateVariables(initialVars);
    setIsTemplateModalOpen(true);
  };

  const handleCompileAndLoadTemplate = () => {
    if (!selectedTemplate) return;
    let compiled = selectedTemplate.template;
    selectedTemplate.variables.forEach(v => {
      const val = templateVariables[v] || `[${v}]`;
      compiled = compiled.replace(new RegExp(`{{${v}}}`, 'g'), val);
    });
    setInputMessage(compiled);
    setIsTemplateModalOpen(false);
    setSelectedTemplate(null);
  };

  return (
    <div
      id="cai-root-container"
      className="flex h-screen w-full bg-[#09090b] text-[#e4e4e7] font-sans overflow-hidden select-none"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* File Drop Overlay */}
      {isDragging && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-[#020205]/90 backdrop-blur-md border-4 border-dashed border-indigo-500/80 animate-fade-in pointer-events-none">
          <Paperclip className="h-16 w-16 text-indigo-400 animate-bounce mb-4" />
          <h2 className="text-xl font-bold text-white">Drop images to attach directly</h2>
          <p className="text-sm text-indigo-300 mt-1">Accepts PNG, JPG, JPEG, and WebP for multimodal context</p>
        </div>
      )}

      {/* Backdrop for Left Sidebar on mobile/tablet */}
      {isLeftSidebarOpen && (
        <div 
          onClick={() => setIsLeftSidebarOpen(false)}
          className="fixed inset-0 z-35 bg-black/60 backdrop-blur-xs lg:hidden transition-opacity duration-300 animate-fade-in"
        />
      )}

      {/* Backdrop for Right Sidebar on mobile/tablet */}
      {isRightSuiteOpen && (
        <div 
          onClick={() => setIsRightSuiteOpen(false)}
          className="fixed inset-0 z-35 bg-black/60 backdrop-blur-xs lg:hidden transition-opacity duration-300 animate-fade-in"
        />
      )}

      {/* 1. Left Sidebar: Navigation, Thread History, User profile */}
      <ChatSidebar
        sessions={sessions}
        activeSessionId={activeSessionId}
        onSelectSession={(id) => {
          setActiveSessionId(id);
          setIsLeftSidebarOpen(false);
        }}
        onNewChat={() => {
          handleNewChat();
          setIsLeftSidebarOpen(false);
        }}
        onDeleteSession={handleDeleteSession}
        onRenameSession={handleRenameSession}
        onClearAllSessions={handleClearAllSessions}
        userEmail="jionnipetty@gmail.com"
        isOpen={isLeftSidebarOpen}
        onClose={() => setIsLeftSidebarOpen(false)}
      />

      {/* 2. Central Area: Active Chat and Top metrics bar */}
      <div id="cai-chat-central" className="flex-1 flex flex-col relative bg-[#09090b] min-w-0">
        
        {/* Top metrics bar */}
        <div id="cai-metrics-bar" className="h-16 border-b border-white/10 bg-[#09090b]/80 backdrop-blur-md px-4 md:px-6 flex items-center justify-between sticky top-0 z-10 shrink-0 gap-3">
          <div className="flex items-center gap-3 min-w-0 flex-1">
            {/* Hamburger Menu on smaller screens */}
            <button
              onClick={() => setIsLeftSidebarOpen(!isLeftSidebarOpen)}
              className="lg:hidden p-2 rounded-xl border border-white/10 bg-white/5 text-white/60 hover:text-white hover:bg-white/10 transition-all active:scale-95 cursor-pointer shrink-0"
              title="Toggle Navigation Sidebar"
            >
              <Menu className="h-4 w-4" />
            </button>

            {/* Metrics parameters list */}
            <div className="flex gap-6 overflow-x-auto no-scrollbar py-1 flex-1">
              <div className="flex flex-col min-w-28 shrink-0">
                <span className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider">Model Node</span>
                <span className="text-xs font-bold text-white uppercase">{modelConfig.model}</span>
              </div>
              <div className="w-[1px] h-6 bg-white/10 my-auto shrink-0"></div>
              <div className="flex flex-col min-w-20 shrink-0">
                <span className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider">Temperature</span>
                <span className="text-xs font-bold text-white">
                  {modelConfig.temperature.toFixed(2)} <span className="text-[9px] text-white/40 ml-1 font-normal font-sans">Active</span>
                </span>
              </div>
              <div className="w-[1px] h-6 bg-white/10 my-auto shrink-0"></div>
              <div className="flex flex-col min-w-24 shrink-0">
                <span className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider">Context Limit</span>
                <span className="text-xs font-bold text-white">128k Tokens</span>
              </div>
              <div className="w-[1px] h-6 bg-white/10 my-auto shrink-0"></div>
              <div className="flex flex-col min-w-24 shrink-0">
                <span className="text-[9px] text-indigo-400 font-mono uppercase tracking-wider">System Prompt</span>
                <span className="text-xs font-bold text-indigo-300 truncate max-w-32" title={customSystemPrompt}>
                  {DEFAULT_SYSTEM_PROMPTS.find(p => p.id === activeSystemPromptId)?.name || 'Custom Persona'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {/* Right Suite Toggle */}
            <button
              onClick={() => setIsRightSuiteOpen(!isRightSuiteOpen)}
              className={`p-2 rounded-xl border border-white/10 transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 text-xs font-semibold ${
                isRightSuiteOpen ? 'bg-indigo-600/20 text-indigo-300 border-indigo-500/40' : 'bg-white/5 text-white/60 hover:text-white hover:bg-white/10'
              }`}
              title="Toggle Prompt Engineering Suite"
            >
              <Wrench className="h-4 w-4" />
              <span className="hidden md:inline">Engineering Suite</span>
            </button>
            <div className="hidden sm:flex items-center gap-1.5 shrink-0 bg-white/5 px-2.5 py-1 rounded-full border border-white/5">
              <span className={`h-2 w-2 rounded-full ${isStreaming ? 'bg-amber-500 animate-ping' : 'bg-green-500'} shrink-0`}></span>
              <span className="text-[10px] font-mono text-white/60">{isStreaming ? 'STREAMING ACTIVE' : 'SECURE CONNECT'}</span>
            </div>
          </div>
        </div>

        {/* Dynamic Chat Area */}
        <div id="cai-chat-viewport" className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 space-y-6 bg-radial-at-t from-indigo-950/10 to-transparent">
          {!activeSession || activeSession.messages.length === 0 ? (
            /* Welcome Area if chat is new/empty */
            <div className="max-w-3xl mx-auto flex flex-col justify-center h-full text-center space-y-8 py-10 animate-fade-in">
              <div className="space-y-3">
                <div className="inline-flex h-12 w-12 rounded-2xl bg-gradient-to-tr from-indigo-500 to-indigo-600 items-center justify-center shadow-[0_0_20px_rgba(79,70,229,0.4)] mb-2">
                  <Sparkles className="h-6 w-6 text-white" />
                </div>
                <h2 className="text-3xl font-extrabold tracking-tight text-white">How can CAI help you build today?</h2>
                <p className="text-sm text-white/50 max-w-md mx-auto">
                  A high-capacity general purpose intelligence configured with elite prompt engineering tools. Select a template below to begin.
                </p>
              </div>

              {/* Grid of Templates in Welcome Screen */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl mx-auto text-left">
                {DEFAULT_PROMPT_TEMPLATES.map((template) => {
                  return (
                    <button
                      key={template.id}
                      onClick={() => openTemplateModal(template)}
                      className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-indigo-500/50 hover:bg-white/10 transition-all text-left group cursor-pointer active:scale-[0.99] flex gap-3"
                    >
                      <div className="p-2.5 rounded-xl bg-white/5 group-hover:bg-indigo-600/20 group-hover:text-indigo-300 text-white/70 transition-colors shrink-0 h-10 w-10 flex items-center justify-center">
                        {template.id === 'code-review' && <Code2 className="h-5 w-5" />}
                        {template.id === 'explain-concept' && <GraduationCap className="h-5 w-5" />}
                        {template.id === 'blog-post' && <BookOpen className="h-5 w-5" />}
                        {template.id === 'email-pitch' && <Mail className="h-5 w-5" />}
                        {template.id === 'refactor-pattern' && <Terminal className="h-5 w-5" />}
                      </div>
                      <div className="space-y-1">
                        <h4 className="text-xs font-bold text-white group-hover:text-indigo-300 transition-colors">{template.name}</h4>
                        <p className="text-[11px] text-white/40 leading-normal">{template.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Fast Tips Block */}
              <div className="max-w-lg mx-auto bg-white/5 border border-white/5 rounded-2xl p-4 flex gap-3 text-left">
                <Info className="h-5 w-5 text-indigo-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-white">Advanced Multimodal Capabilities</h4>
                  <p className="text-[11px] text-white/40 leading-relaxed">
                    You can drag and drop raw images into the chat panel to include visual context in your prompts. Use the Parameters tab to tweak temperature and output lengths instantly.
                  </p>
                </div>
              </div>
            </div>
          ) : (
            /* Render list of chat messages */
            <div className="max-w-3xl mx-auto space-y-6">
              {/* Thread Summarizer Panel */}
              <div className="bg-gradient-to-r from-indigo-950/25 via-purple-950/15 to-[#0f0f15]/30 border border-white/5 rounded-2xl p-4 flex flex-col gap-3 shadow-xl">
                <div className="flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 shrink-0 border border-indigo-500/10 shadow-[0_0_15px_rgba(99,102,241,0.05)]">
                      <Minimize2 className="h-4 w-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider">Choose not to read everything?</h4>
                      <p className="text-[10px] text-white/40 leading-normal">Condense this entire thread history into a single cohesive paragraph.</p>
                    </div>
                  </div>
                  <button
                    onClick={handleSummarizeSession}
                    disabled={sessionSummaries[activeSession.id]?.loading}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold tracking-wide transition-all active:scale-[0.98] cursor-pointer flex items-center gap-1.5 shrink-0 ${
                      sessionSummaries[activeSession.id]?.isOpen
                        ? 'bg-indigo-600 text-white shadow-[0_0_15px_rgba(79,70,229,0.3)]'
                        : 'bg-white/5 hover:bg-white/10 text-white/70 border border-white/5'
                    }`}
                  >
                    {sessionSummaries[activeSession.id]?.loading ? (
                      <span className="h-3 w-3 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></span>
                    ) : (
                      <Sparkles className="h-3.5 w-3.5 text-indigo-300 animate-pulse" />
                    )}
                    <span>{sessionSummaries[activeSession.id]?.isOpen ? 'Hide Summary' : 'Summarize'}</span>
                  </button>
                </div>

                {/* Summarized conversation output banner */}
                {sessionSummaries[activeSession.id]?.isOpen && (
                  <div className="border-t border-white/5 pt-3 animate-fade-in">
                    {sessionSummaries[activeSession.id]?.loading ? (
                      <div className="flex items-center gap-2 text-xs text-white/40 py-2 font-mono">
                        <span className="h-3 w-3 border border-indigo-400 border-t-transparent rounded-full animate-spin"></span>
                        <span>Compiling conversational context tree...</span>
                      </div>
                    ) : (
                      <div className="bg-black/35 border border-white/5 rounded-xl p-3.5">
                        <p className="text-xs font-medium text-indigo-200/90 leading-relaxed select-text italic">
                          "{sessionSummaries[activeSession.id]?.text}"
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {activeSession.messages.map((msg) => {
                const isUser = msg.role === 'user';
                const isSystem = msg.role === 'system';

                if (isSystem) {
                  return (
                    <div key={msg.id} className="flex gap-3 bg-red-950/20 border border-red-900/30 rounded-2xl p-4 text-xs text-red-200 animate-fade-in">
                      <AlertTriangle className="h-4.5 w-4.5 shrink-0 text-red-400" />
                      <div className="space-y-1">
                        <span className="font-bold uppercase tracking-wider text-[10px] text-red-400 block">Critical System Event</span>
                        <p className="leading-relaxed select-text">{msg.content}</p>
                      </div>
                    </div>
                  );
                }

                return (
                  <div key={msg.id} className={`flex gap-4 animate-fade-in ${isUser ? 'justify-end' : 'justify-start'}`}>
                    {/* Assistant Profile Icon */}
                    {!isUser && (
                      <div className="w-8 h-8 rounded-lg bg-indigo-600 flex-shrink-0 flex items-center justify-center shadow-[0_0_10px_rgba(79,70,229,0.3)] border border-indigo-400/20">
                        <span className="text-white font-black text-xs italic">C</span>
                      </div>
                    )}

                    {/* Chat Bubble content */}
                    <div className={`max-w-[85%] space-y-2 ${isUser ? 'order-1' : 'order-2'}`}>
                      {/* Attached Images */}
                      {msg.attachments && msg.attachments.length > 0 && (
                        <div className="flex flex-wrap gap-2 justify-end mb-2">
                          {msg.attachments.map((att, attIdx) => (
                            <div key={attIdx} className="relative rounded-lg overflow-hidden border border-white/10 group shadow-md max-w-[200px]">
                              <img src={att.data} alt={att.name} className="max-h-32 object-contain bg-black" />
                              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2 text-center">
                                <span className="text-[10px] text-white font-mono truncate">{att.name}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      <div className={`p-5 rounded-2xl border leading-relaxed shadow-xl ${
                        isUser
                          ? 'bg-indigo-600/10 border-indigo-500/20 text-white'
                          : 'bg-white/5 border-white/10 text-white/90'
                      }`}>
                        {isUser ? (
                          <p className="text-sm leading-relaxed whitespace-pre-wrap select-text">{msg.content}</p>
                        ) : (
                          <>
                            {messageSummaries[msg.id]?.isViewingSummary ? (
                              <div className="space-y-2 animate-fade-in select-text">
                                <div className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-400 uppercase tracking-widest font-mono">
                                  <Minimize2 className="h-3.5 w-3.5" />
                                  <span>Condensed Response Summary</span>
                                </div>
                                {messageSummaries[msg.id].loading ? (
                                  <div className="flex items-center gap-2 text-xs text-white/40 font-mono py-1">
                                    <span className="h-3 w-3 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin"></span>
                                    <span>Compressing dialogue stream...</span>
                                  </div>
                                ) : (
                                  <p className="text-sm leading-relaxed text-indigo-100 font-medium italic border-l-2 border-indigo-500/40 pl-3">
                                    "{messageSummaries[msg.id].text}"
                                  </p>
                                )}
                              </div>
                            ) : (
                              <MarkdownRenderer content={msg.content} />
                            )}
                          </>
                        )}

                        {/* Rendering steps/stages inside assistant messages for simulated analytical depth */}
                        {!isUser && msg.isEnhanced && (
                          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-2.5 border-t border-white/5 pt-3">
                            <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded text-[10px] font-mono text-white/80">
                              <span className="text-indigo-400 font-bold tracking-wider mr-1">// STAGE 01</span> Analysis of seed prompt completed.
                            </div>
                            <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 rounded text-[10px] font-mono text-white/80">
                              <span className="text-indigo-400 font-bold tracking-wider mr-1">// STAGE 02</span> Real-time context feedback stabilized.
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Message Footer metadata */}
                      <div className={`flex items-center gap-3 text-[10px] text-white/30 px-1 ${isUser ? 'justify-end' : 'justify-start'}`}>
                        <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        {!isUser && msg.modelUsed && (
                          <>
                            <span>•</span>
                            <span className="font-mono uppercase text-indigo-400/80 font-semibold">{msg.modelUsed}</span>
                          </>
                        )}
                        {!isUser && (
                          <>
                            <span>•</span>
                            <button
                              onClick={() => handleSummarizeMessage(msg.id, msg.content)}
                              className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded border flex items-center gap-1.5 hover:bg-white/10 hover:text-white transition-all cursor-pointer ${
                                messageSummaries[msg.id]?.isViewingSummary
                                  ? 'bg-indigo-500/15 text-indigo-300 border-indigo-500/35'
                                  : 'bg-white/5 text-white/55 border-white/10'
                              }`}
                              title={messageSummaries[msg.id]?.isViewingSummary ? "Show full detailed text" : "Summarize into one short paragraph"}
                            >
                              <Sparkles className="h-2.5 w-2.5 text-indigo-400" />
                              <span>{messageSummaries[msg.id]?.isViewingSummary ? 'Show Full Response' : 'Summarize'}</span>
                            </button>
                          </>
                        )}
                        {!isUser && msg.cost !== undefined && (
                          <>
                            <span>•</span>
                            <span className="font-mono text-emerald-400/85 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/10 uppercase tracking-wider">
                              Cost: ${msg.cost.toFixed(6)}
                            </span>
                          </>
                        )}
                      </div>
                    </div>

                    {/* User Profile Icon */}
                    {isUser && (
                      <div className="w-8 h-8 rounded-lg bg-white/10 flex-shrink-0 flex items-center justify-center font-bold text-xs text-white/80 order-3 border border-white/10">
                        US
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Streaming Assistant bubble placeholder */}
              {isStreaming && streamedText && (
                <div className="flex gap-4 animate-fade-in justify-start">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 flex-shrink-0 flex items-center justify-center shadow-[0_0_10px_rgba(79,70,229,0.3)] border border-indigo-400/20">
                    <span className="text-white font-black text-xs italic">C</span>
                  </div>
                  <div className="max-w-[85%] space-y-2 order-2">
                    <div className="p-5 rounded-2xl border leading-relaxed shadow-xl bg-white/5 border-white/10 text-white/90">
                      <MarkdownRenderer content={streamedText} />
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-white/30 px-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-indigo-400 animate-ping"></span>
                      <span>Streaming response chunk...</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Loading spinner for empty streaming state */}
              {isStreaming && !streamedText && (
                <div className="flex gap-4 animate-pulse justify-start">
                  <div className="w-8 h-8 rounded-lg bg-indigo-600 flex-shrink-0 flex items-center justify-center">
                    <span className="text-white font-black text-xs italic">C</span>
                  </div>
                  <div className="p-4 rounded-2xl bg-white/5 border border-white/10 max-w-[85%] flex items-center gap-3">
                    <div className="h-4 w-4 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-xs text-white/60">Securing quantum communication line...</span>
                  </div>
                </div>
              )}

              <div ref={chatEndRef} />
            </div>
          )}
        </div>

        {/* Bottom Input Area */}
        <div id="cai-input-wrapper" className="p-4 md:p-6 shrink-0 border-t border-white/5 bg-[#09090b]/80 backdrop-blur-md">
          <div className="max-w-3xl mx-auto bg-[#121217] border border-white/10 rounded-2xl p-1.5 shadow-2xl relative">
            
            {/* Quick Action bar above text box */}
            <div className="flex items-center gap-2 px-3 py-1.5 border-b border-white/5 select-none overflow-x-auto no-scrollbar">
              <span className="text-[9px] font-bold text-white/30 uppercase tracking-wider shrink-0 mr-1">Quick Tools:</span>
              <button
                onClick={() => {
                  if (activeSession) {
                    openTemplateModal(DEFAULT_PROMPT_TEMPLATES[0]);
                  } else {
                    alert('Please select or create a conversation thread first.');
                  }
                }}
                className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-[10px] font-bold uppercase tracking-wider text-white/70 hover:text-white transition-all cursor-pointer flex items-center gap-1 shrink-0"
              >
                <Code2 className="h-3 w-3 text-indigo-400" />
                <span>Code Review</span>
              </button>
              <button
                onClick={() => {
                  if (activeSession) {
                    openTemplateModal(DEFAULT_PROMPT_TEMPLATES[1]);
                  } else {
                    alert('Please select or create a conversation thread first.');
                  }
                }}
                className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-[10px] font-bold uppercase tracking-wider text-white/70 hover:text-white transition-all cursor-pointer flex items-center gap-1 shrink-0"
              >
                <GraduationCap className="h-3 w-3 text-indigo-400" />
                <span>Explain Concept</span>
              </button>
              
              <div className="flex-1"></div>
              
              <div className="text-[9px] text-white/30 font-mono tracking-wider shrink-0 uppercase">
                {inputMessage.length} / 4096 Characters
              </div>
            </div>

            {/* Input fields panel */}
            <div className="flex flex-col p-2 space-y-2 bg-[#121217]">
              {/* Attachment Previews */}
              {uploadedAttachments.length > 0 && (
                <div className="flex flex-wrap gap-2 bg-white/5 p-2 rounded-xl border border-white/5">
                  {uploadedAttachments.map((att, index) => (
                    <div key={index} className="relative group shrink-0 h-14 w-14 rounded-lg overflow-hidden border border-white/10 bg-black">
                      <img src={att.data} alt={att.name} className="h-full w-full object-cover" />
                      <button
                        onClick={() => removeAttachment(index)}
                        className="absolute top-0.5 right-0.5 bg-black/70 hover:bg-red-600 rounded-full p-0.5 text-white transition-all cursor-pointer shadow-md"
                        title="Remove image"
                      >
                        <X className="h-2.5 w-2.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Primary Textarea */}
              <div className="flex items-end gap-3.5">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all cursor-pointer border border-white/5 hover:border-white/10 shrink-0 mb-1"
                  title="Attach multimodal image context"
                >
                  <ImageIcon className="h-4 w-4" />
                </button>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileSelectChange}
                  accept="image/*"
                  multiple
                  className="hidden"
                />

                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  disabled={!activeSessionId || isStreaming}
                  placeholder={
                    activeSessionId
                      ? 'Ask CAI anything... (Press Enter to send, Shift+Enter for newline)'
                      : 'Create or select a thread from the left panel to begin communicating...'
                  }
                  rows={2}
                  className="flex-1 bg-transparent border-none focus:ring-0 focus:outline-none text-sm placeholder-white/20 text-white resize-none leading-relaxed min-h-[44px] py-1 selection:bg-indigo-700/80"
                />

                <button
                  onClick={() => handleSendMessage()}
                  disabled={isStreaming || (!inputMessage.trim() && uploadedAttachments.length === 0) || !activeSessionId}
                  className="p-3 bg-indigo-600 rounded-xl hover:bg-indigo-500 text-white transition-all shadow-lg shadow-indigo-600/20 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer mb-1 shrink-0"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
          
          <p className="text-center text-[9px] mt-4 text-white/20 font-mono uppercase tracking-[0.2em] select-none">
            Encrypted Communication Tunnel: 256-Bit SSL Active
          </p>
        </div>
      </div>

      {/* 3. Collapsible Right Sidebar: Prompt Engineering Suite & Parameters */}
      <PromptEngineeringTools
        modelConfig={modelConfig}
        setModelConfig={setModelConfig}
        activeSystemPromptId={activeSystemPromptId}
        setActiveSystemPromptId={handleSelectSystemPrompt}
        customSystemPrompt={customSystemPrompt}
        setCustomSystemPrompt={setCustomSystemPrompt}
        onLoadEnhancedPrompt={(promptText) => {
          handleLoadEnhancedPrompt(promptText);
          setIsRightSuiteOpen(false); // Close on mobile/tablet when loaded
        }}
        isOpen={isRightSuiteOpen}
        onClose={() => setIsRightSuiteOpen(false)}
        walletBalance={walletBalance}
        setWalletBalance={setWalletBalance}
        paymentMethod={paymentMethod}
        setPaymentMethod={setPaymentMethod}
        billingPriority={billingPriority}
        setBillingPriority={setBillingPriority}
        keysStatus={keysStatus}
      />

      {/* 4. Prompt Template Dynamic Variable Form Modal */}
      {isTemplateModalOpen && selectedTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-[#121217] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl animate-scale-in">
            {/* Modal Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-indigo-950/20 to-transparent">
              <div className="flex items-center gap-2">
                <Layers className="h-4.5 w-4.5 text-indigo-400" />
                <h3 className="text-sm font-bold text-white tracking-tight">{selectedTemplate.name}</h3>
              </div>
              <button
                onClick={() => {
                  setIsTemplateModalOpen(false);
                  setSelectedTemplate(null);
                }}
                className="text-white/40 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-all cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Modal Body with form fields */}
            <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto no-scrollbar">
              <p className="text-xs text-white/50 leading-relaxed">{selectedTemplate.description}</p>
              
              <div className="space-y-3">
                {selectedTemplate.variables.map((variable) => {
                  const isMultiline = variable === 'code' || variable === 'topic' || variable === 'prompt';
                  return (
                    <div key={variable} className="space-y-1">
                      <label className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider block">
                        {variable.replace(/_/g, ' ')}
                      </label>
                      {isMultiline ? (
                        <textarea
                          value={templateVariables[variable] || ''}
                          onChange={(e) => setTemplateVariables(prev => ({ ...prev, [variable]: e.target.value }))}
                          placeholder={`Enter custom ${variable}...`}
                          rows={3}
                          className="w-full text-xs rounded-xl border border-white/10 bg-[#09090b] p-3 text-white placeholder-white/10 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none font-mono"
                        />
                      ) : (
                        <input
                          type="text"
                          value={templateVariables[variable] || ''}
                          onChange={(e) => setTemplateVariables(prev => ({ ...prev, [variable]: e.target.value }))}
                          placeholder={`e.g. ${variable === 'language' ? 'TypeScript' : 'Senior Analyst'}`}
                          className="w-full text-xs rounded-xl border border-white/10 bg-[#09090b] p-2.5 text-white placeholder-white/10 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                        />
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Footer actions */}
            <div className="p-4 border-t border-white/10 bg-white/2 flex gap-3 justify-end">
              <button
                onClick={() => {
                  setIsTemplateModalOpen(false);
                  setSelectedTemplate(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-white/60 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleCompileAndLoadTemplate}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-all shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <span>Inject Template</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
