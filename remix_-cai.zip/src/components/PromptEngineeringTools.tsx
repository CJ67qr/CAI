import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import { ModelConfig } from '../types';
import { DEFAULT_SYSTEM_PROMPTS, AI_MODELS } from '../data';

interface PromptEngineeringToolsProps {
  modelConfig: ModelConfig;
  setModelConfig: (config: ModelConfig) => void;
  activeSystemPromptId: string;
  setActiveSystemPromptId: (id: string) => void;
  customSystemPrompt: string;
  setCustomSystemPrompt: (prompt: string) => void;
  onLoadEnhancedPrompt: (prompt: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
  walletBalance: number;
  setWalletBalance: React.Dispatch<React.SetStateAction<number>>;
  paymentMethod: 'credits' | 'card' | 'subscription';
  setPaymentMethod: (m: 'credits' | 'card' | 'subscription') => void;
  billingPriority: 'eco' | 'standard' | 'priority';
  setBillingPriority: (p: 'eco' | 'standard' | 'priority') => void;
  keysStatus: { openai: boolean; anthropic: boolean };
}

export interface SavedPaymentMethod {
  id: string;
  type: 'visa' | 'mastercard' | 'amex' | 'paypal' | 'applepay' | 'googlepay';
  name: string;
  last4?: string;
  email?: string;
  isDefault: boolean;
}

export default function PromptEngineeringTools({
  modelConfig,
  setModelConfig,
  activeSystemPromptId,
  setActiveSystemPromptId,
  customSystemPrompt,
  setCustomSystemPrompt,
  onLoadEnhancedPrompt,
  isOpen = false,
  onClose,
  walletBalance,
  setWalletBalance,
  paymentMethod,
  setPaymentMethod,
  billingPriority,
  setBillingPriority,
  keysStatus,
}: PromptEngineeringToolsProps) {
  const [activeTab, setActiveTab] = useState<'enhancer' | 'persona' | 'models' | 'billing'>('enhancer');
  
  // Prompt Enhancer States
  const [rawPrompt, setRawPrompt] = useState('');
  const [enhancedResult, setEnhancedResult] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhanceCopied, setEnhanceCopied] = useState(false);
  const [enhanceError, setEnhanceError] = useState('');

  // Toast / Status states for billing actions
  const [billingToast, setBillingToast] = useState('');

  // --- Saved Payment Methods States ---
  const [savedMethods, setSavedMethods] = useState<SavedPaymentMethod[]>(() => {
    const saved = localStorage.getItem('cai_saved_payment_methods');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback below
      }
    }
    return [
      {
        id: 'pm-1',
        type: 'visa',
        name: 'Jionni Petty',
        last4: '4242',
        isDefault: true
      },
      {
        id: 'pm-2',
        type: 'paypal',
        name: 'PayPal Sandbox Account',
        email: 'jionnipetty@gmail.com',
        isDefault: false
      },
      {
        id: 'pm-3',
        type: 'mastercard',
        name: 'Corporate Card',
        last4: '8899',
        isDefault: false
      }
    ];
  });

  const saveMethodsToStorage = (methods: SavedPaymentMethod[]) => {
    setSavedMethods(methods);
    localStorage.setItem('cai_saved_payment_methods', JSON.stringify(methods));
  };

  // Add payment method form states
  const [isAddingMethod, setIsAddingMethod] = useState(false);
  const [newMethodType, setNewMethodType] = useState<'visa' | 'mastercard' | 'amex' | 'paypal' | 'applepay' | 'googlepay'>('visa');
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [paypalEmail, setPaypalEmail] = useState('');

  // Refill checkout flow states
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutAmount, setCheckoutAmount] = useState<number>(10.00);
  const [selectedMethodId, setSelectedMethodId] = useState<string>('pm-1');
  const [isProcessingCheckout, setIsProcessingCheckout] = useState(false);

  // Handle Prompt Enhancement API Call
  const handleEnhance = async () => {
    if (!rawPrompt.trim()) return;
    setIsEnhancing(true);
    setEnhanceError('');
    try {
      const response = await fetch('/api/enhance-prompt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: rawPrompt }),
      });
      const data = await response.json();
      if (data.error) {
        throw new Error(data.error);
      }
      setEnhancedResult(data.enhancedPrompt || '');
    } catch (err: any) {
      console.error(err);
      setEnhanceError(err.message || 'Failed to enhance prompt. Check server logs.');
    } finally {
      setIsEnhancing(false);
    }
  };

  const copyEnhanced = async () => {
    if (!enhancedResult) return;
    try {
      await navigator.clipboard.writeText(enhancedResult);
      setEnhanceCopied(true);
      setTimeout(() => setEnhanceCopied(false), 2000);
    } catch (err) {
      console.error(err);
    }
  };

  const handleRefillWallet = () => {
    // Open the checkout flow first so the user gets a highly polished, interactive payment confirmation!
    setIsCheckoutOpen(true);
    // Auto-select the default payment method
    const defaultMethod = savedMethods.find(m => m.isDefault) || savedMethods[0];
    if (defaultMethod) {
      setSelectedMethodId(defaultMethod.id);
    }
  };

  const handleConfirmRefill = () => {
    setIsProcessingCheckout(true);
    const activeMethod = savedMethods.find(m => m.id === selectedMethodId) || savedMethods[0];
    const methodName = activeMethod 
      ? (activeMethod.type === 'paypal' ? `PayPal (${activeMethod.email})` : `${activeMethod.type.toUpperCase()} •••• ${activeMethod.last4}`)
      : 'Selected Payment Method';

    setTimeout(() => {
      setWalletBalance(prev => prev + checkoutAmount);
      setIsProcessingCheckout(false);
      setIsCheckoutOpen(false);
      showToast(`SUCCESSFULLY CHARGED ${methodName.toUpperCase()} & REFILLED +$${checkoutAmount.toFixed(2)} COGNITIVE CREDITS!`);
    }, 1500); // realistic payment latency animation
  };

  const handleAddPaymentMethod = (e: React.FormEvent) => {
    e.preventDefault();
    
    let newItem: SavedPaymentMethod;
    const isFirst = savedMethods.length === 0;

    if (newMethodType === 'paypal') {
      if (!paypalEmail.trim() || !paypalEmail.includes('@')) {
        showToast('ERROR: PLEASE ENTER A VALID PAYPAL EMAIL ADDRESS!');
        return;
      }
      newItem = {
        id: `pm-${Date.now()}`,
        type: 'paypal',
        name: 'PayPal Sandbox Account',
        email: paypalEmail.trim(),
        isDefault: isFirst
      };
    } else if (newMethodType === 'applepay' || newMethodType === 'googlepay') {
      newItem = {
        id: `pm-${Date.now()}`,
        type: newMethodType,
        name: `${newMethodType === 'applepay' ? 'Apple Pay' : 'Google Pay'} Device`,
        isDefault: isFirst
      };
    } else {
      // Cards
      if (!cardName.trim()) {
        showToast('ERROR: CARDHOLDER NAME IS REQUIRED!');
        return;
      }
      const sanitizedCard = cardNumber.replace(/\D/g, '');
      if (sanitizedCard.length < 4) {
        showToast('ERROR: INVALID CARD NUMBER!');
        return;
      }
      const last4 = sanitizedCard.slice(-4);
      newItem = {
        id: `pm-${Date.now()}`,
        type: newMethodType,
        name: cardName.trim(),
        last4: last4,
        isDefault: isFirst
      };
    }

    const updated = [...savedMethods, newItem];
    saveMethodsToStorage(updated);
    
    // Reset form
    setCardName('');
    setCardNumber('');
    setCardExpiry('');
    setCardCvv('');
    setPaypalEmail('');
    setIsAddingMethod(false);

    showToast(`SUCCESSFULLY SAVED NEW ${newMethodType.toUpperCase()} PAYMENT METHOD!`);
  };

  const handleDeleteMethod = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const toDelete = savedMethods.find(m => m.id === id);
    if (!toDelete) return;

    if (toDelete.isDefault && savedMethods.length > 1) {
      showToast('ERROR: SET ANOTHER METHOD AS DEFAULT BEFORE DELETING!');
      return;
    }

    const filtered = savedMethods.filter(m => m.id !== id);
    // If we deleted default, set first remaining as default
    if (toDelete.isDefault && filtered.length > 0) {
      filtered[0].isDefault = true;
    }
    
    saveMethodsToStorage(filtered);
    showToast(`REMOVED ${toDelete.type.toUpperCase()} PAYMENT METHOD.`);
  };

  const handleSetDefaultMethod = (id: string) => {
    const updated = savedMethods.map(m => ({
      ...m,
      isDefault: m.id === id
    }));
    saveMethodsToStorage(updated);
    const activeMethod = updated.find(m => m.id === id);
    if (activeMethod) {
      showToast(`DEFAULT PAYMENT METHOD SET TO: ${activeMethod.type.toUpperCase()}`);
    }
  };

  const getMethodIcon = (type: string) => {
    switch (type) {
      case 'paypal':
        return <Icons.Wallet className="h-4 w-4 text-sky-400" />;
      case 'applepay':
        return <Icons.Smartphone className="h-4 w-4 text-white" />;
      case 'googlepay':
        return <Icons.QrCode className="h-4 w-4 text-emerald-400" />;
      default:
        return <Icons.CreditCard className="h-4 w-4 text-indigo-400" />;
    }
  };

  const showToast = (msg: string) => {
    setBillingToast(msg);
    setTimeout(() => setBillingToast(''), 3000);
  };

  const getTemperatureDescriptor = (temp: number) => {
    if (temp <= 0.3) return 'Strictly Precise (Code & Math)';
    if (temp <= 0.7) return 'Balanced & Logical (General Q&A)';
    if (temp <= 1.1) return 'Creative & Expressive (Writing & Ideas)';
    return 'Hyper-Creative (Experimental & Brainstorm)';
  };

  return (
    <div className={`flex h-full flex-col bg-[#0d0d11] border-l border-white/5 shrink-0 transition-all duration-300 ease-in-out
      fixed inset-y-0 right-0 z-40 w-[320px] max-w-[90vw] sm:w-[380px]
      lg:static lg:h-full lg:max-w-none
      ${isOpen 
        ? 'translate-x-0 opacity-100 lg:w-[380px] lg:opacity-100' 
        : 'translate-x-full opacity-0 lg:translate-x-0 lg:w-0 lg:border-l-0 lg:opacity-0 pointer-events-none lg:pointer-events-none'
      }
    `}>
      {/* Title Header */}
      <div className="p-4 border-b border-white/5 flex items-center justify-between gap-2 bg-[#09090b]">
        <div className="flex items-center gap-2">
          <Icons.Wrench className="h-4 w-4 text-indigo-400 animate-pulse" />
          <h2 className="text-xs font-bold text-white uppercase tracking-wider">Engineering Suite</h2>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
            title="Close Suite"
          >
            <Icons.X className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Tabs list */}
      <div className="flex border-b border-white/5 px-1 pt-1.5 bg-[#09090b]">
        <button
          onClick={() => setActiveTab('enhancer')}
          className={`flex-1 flex flex-col items-center gap-1 py-2 px-1 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 transition-all cursor-pointer ${
            activeTab === 'enhancer'
              ? 'border-indigo-500 bg-[#0d0d11] text-white'
              : 'border-transparent text-white/40 hover:text-white/80'
          }`}
          title="Enhance Raw Prompts"
        >
          <Icons.Sparkles className="h-3.5 w-3.5 text-indigo-400" />
          <span>Enhance</span>
        </button>
        <button
          onClick={() => setActiveTab('persona')}
          className={`flex-1 flex flex-col items-center gap-1 py-2 px-1 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 transition-all cursor-pointer ${
            activeTab === 'persona'
              ? 'border-indigo-500 bg-[#0d0d11] text-white'
              : 'border-transparent text-white/40 hover:text-white/80'
          }`}
          title="Choose AI Persona"
        >
          <Icons.Cpu className="h-3.5 w-3.5 text-indigo-400" />
          <span>Persona</span>
        </button>
        <button
          onClick={() => setActiveTab('models')}
          className={`flex-1 flex flex-col items-center gap-1 py-2 px-1 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 transition-all cursor-pointer ${
            activeTab === 'models'
              ? 'border-indigo-500 bg-[#0d0d11] text-white'
              : 'border-transparent text-white/40 hover:text-white/80'
          }`}
          title="Configure AI Models"
        >
          <Icons.Sliders className="h-3.5 w-3.5 text-indigo-400" />
          <span>Models</span>
        </button>
        <button
          onClick={() => setActiveTab('billing')}
          className={`flex-1 flex flex-col items-center gap-1 py-2 px-1 text-[10px] font-bold uppercase tracking-wider rounded-t-lg border-b-2 transition-all cursor-pointer ${
            activeTab === 'billing'
              ? 'border-indigo-500 bg-[#0d0d11] text-white'
              : 'border-transparent text-white/40 hover:text-white/80'
          }`}
          title="Billing & Payment Tiers"
        >
          <Icons.CreditCard className="h-3.5 w-3.5 text-indigo-400" />
          <span>Billing</span>
        </button>
      </div>

      {/* Dynamic Toast Message Overlay inside Sidebar */}
      {billingToast && (
        <div className="mx-4 mt-3 p-2 text-center text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 rounded-xl shadow-lg transition-all animate-bounce">
          {billingToast}
        </div>
      )}

      {/* Tab Panels */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
        {activeTab === 'enhancer' && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Raw Prompt Idea</label>
              <p className="text-[11px] text-white/40 leading-relaxed">Describe what you want to achieve. CAI will rewrite it into an optimal structured system prompt.</p>
              <textarea
                value={rawPrompt}
                onChange={(e) => setRawPrompt(e.target.value)}
                placeholder="e.g. Write a python script to parse logs and send email on error"
                rows={4}
                className="w-full text-xs rounded-xl border border-white/10 bg-black/40 p-3 text-white placeholder-white/20 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none"
              />
              <button
                onClick={handleEnhance}
                disabled={isEnhancing || !rawPrompt.trim()}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md active:scale-[0.98] transition-all cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {isEnhancing ? (
                  <>
                    <Icons.Loader2 className="h-3.5 w-3.5 animate-spin text-white" />
                    <span>Compiling Prompt Elements...</span>
                  </>
                ) : (
                  <>
                    <Icons.Sparkles className="h-3.5 w-3.5 text-indigo-200 animate-pulse" />
                    <span>AI Enhance Prompt</span>
                  </>
                )}
              </button>
            </div>

            {enhanceError && (
              <div className="p-3 bg-red-950/20 border border-red-900/30 rounded-xl text-xs text-red-300">
                {enhanceError}
              </div>
            )}

            {enhancedResult && (
              <div className="space-y-2 animate-fade-in pt-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-wider">Engineered Output</span>
                  <div className="flex gap-2">
                    <button
                      onClick={copyEnhanced}
                      className="text-white/40 hover:text-white p-1 rounded hover:bg-white/5 transition-colors cursor-pointer"
                      title="Copy to clipboard"
                    >
                      {enhanceCopied ? (
                        <Icons.Check className="h-3.5 w-3.5 text-emerald-400" />
                      ) : (
                        <Icons.Copy className="h-3.5 w-3.5" />
                      )}
                    </button>
                  </div>
                </div>
                
                <div className="bg-black/30 border border-white/5 rounded-xl p-3 text-[11px] font-mono text-white/85 max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed select-text no-scrollbar">
                  {enhancedResult}
                </div>

                <button
                  onClick={() => onLoadEnhancedPrompt(enhancedResult)}
                  className="w-full flex items-center justify-center gap-1.5 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white text-xs font-medium border border-white/10 transition-all cursor-pointer active:scale-[0.98]"
                >
                  <Icons.Plus className="h-3.5 w-3.5 text-indigo-400" />
                  Load directly into Chat
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'persona' && (
          <div className="space-y-4 animate-fade-in">
            <div className="space-y-1.5">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block font-mono">System Preset Constraints</label>
              <p className="text-[11px] text-white/40">Choose a default assistant persona profile or define custom constraints.</p>
            </div>

            {/* Persona Grid */}
            <div className="space-y-2">
              {DEFAULT_SYSTEM_PROMPTS.map((persona) => {
                const IconComp = (Icons as any)[persona.icon] || Icons.HelpCircle;
                const isSelected = activeSystemPromptId === persona.id;

                return (
                  <button
                    key={persona.id}
                    onClick={() => {
                      setActiveSystemPromptId(persona.id);
                      setCustomSystemPrompt(persona.prompt);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all duration-150 cursor-pointer flex items-start gap-2.5 ${
                      isSelected
                        ? 'bg-indigo-950/20 border-indigo-500/40 shadow-sm shadow-indigo-950'
                        : 'bg-white/[0.02] border-white/5 hover:bg-white/5 hover:border-white/10'
                    }`}
                  >
                    <div className={`p-1.5 rounded-lg shrink-0 ${isSelected ? 'bg-indigo-600 text-white' : 'bg-white/5 text-white/40'}`}>
                      <IconComp className="h-3.5 w-3.5" />
                    </div>
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs font-semibold text-white">{persona.name}</span>
                        {isSelected && <span className="h-1.5 w-1.5 rounded-full bg-indigo-400 animate-pulse" />}
                      </div>
                      <p className="text-[10px] text-white/40 line-clamp-2 leading-relaxed">{persona.description}</p>
                    </div>
                  </button>
                );
              })}

              {/* Custom Persona Selection */}
              <button
                onClick={() => setActiveSystemPromptId('custom')}
                className={`w-full text-left p-3 rounded-xl border transition-all duration-150 cursor-pointer flex items-start gap-2.5 ${
                  activeSystemPromptId === 'custom'
                    ? 'bg-indigo-950/20 border-indigo-500/40 shadow-sm shadow-indigo-950'
                    : 'bg-white/[0.02] border-white/5 hover:bg-white/5 hover:border-white/10'
                }`}
              >
                <div className={`p-1.5 rounded-lg shrink-0 ${activeSystemPromptId === 'custom' ? 'bg-indigo-600 text-white' : 'bg-white/5 text-white/40'}`}>
                  <Icons.PenTool className="h-3.5 w-3.5" />
                </div>
                <div className="space-y-0.5 w-full">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-white">Custom System Persona</span>
                    {activeSystemPromptId === 'custom' && <span className="h-1.5 w-1.5 rounded-full bg-indigo-400 animate-pulse" />}
                  </div>
                  <p className="text-[10px] text-white/40 leading-relaxed">Write your own custom constraints and model guidelines below.</p>
                </div>
              </button>
            </div>

            {/* Custom Instruction Box */}
            <div className="space-y-2 animate-fade-in pt-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-white/50 uppercase tracking-wider">System Prompt Guidelines</span>
                {activeSystemPromptId !== 'custom' && (
                  <span className="text-[9px] text-indigo-400 font-medium font-mono uppercase">Read-Only (Auto Fork on Type)</span>
                )}
              </div>
              <textarea
                value={customSystemPrompt}
                onChange={(e) => {
                  setCustomSystemPrompt(e.target.value);
                  if (activeSystemPromptId !== 'custom') {
                    setActiveSystemPromptId('custom');
                  }
                }}
                placeholder="Write custom instructions. e.g. Answer using bullet points and professional system-architecture terms."
                rows={5}
                className="w-full text-[11px] font-mono rounded-xl border border-white/10 bg-black/40 p-2.5 text-white/85 placeholder-white/20 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 resize-none leading-relaxed select-text"
              />
            </div>
          </div>
        )}

        {activeTab === 'models' && (
          <div className="space-y-5 animate-fade-in">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block font-mono">Cognitive Model Nodes</label>
              <p className="text-[11px] text-white/40">Switch between Google Gemini, OpenAI, or Anthropic models instantly.</p>
            </div>

            {/* Grouped Model Selector */}
            <div className="space-y-4">
              {['Google Gemini', 'OpenAI', 'Anthropic'].map((provider) => {
                const providerModels = AI_MODELS.filter(m => m.provider === provider);
                return (
                  <div key={provider} className="space-y-1.5">
                    <div className="flex items-center justify-between px-1">
                      <span className="text-[9px] font-extrabold text-indigo-400 uppercase tracking-[0.15em] font-mono">{provider}</span>
                      {provider === 'OpenAI' && (
                        <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${keysStatus.openai ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}`}>
                          {keysStatus.openai ? '● Connected Gateway' : '● Sandbox Proxy'}
                        </span>
                      )}
                      {provider === 'Anthropic' && (
                        <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded uppercase ${keysStatus.anthropic ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}`}>
                          {keysStatus.anthropic ? '● Connected Gateway' : '● Sandbox Proxy'}
                        </span>
                      )}
                      {provider === 'Google Gemini' && (
                        <span className="text-[8px] font-mono font-bold px-1.5 py-0.5 rounded uppercase bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                          ● Fully Native
                        </span>
                      )}
                    </div>

                    <div className="space-y-1.5">
                      {providerModels.map((model) => {
                        const isSelected = modelConfig.model === model.id;
                        return (
                          <button
                            key={model.id}
                            onClick={() => setModelConfig({ ...modelConfig, model: model.id })}
                            className={`w-full text-left p-2.5 rounded-xl border transition-all text-xs cursor-pointer flex flex-col gap-1 ${
                              isSelected
                                ? 'bg-indigo-950/20 border-indigo-500 shadow-md shadow-indigo-950'
                                : 'bg-white/[0.01] border-white/5 hover:bg-white/5 hover:border-white/10'
                            }`}
                          >
                            <div className="flex justify-between items-center w-full">
                              <span className="font-bold text-white">{model.name}</span>
                              <div className="flex gap-1 items-center">
                                <span className="text-[9px] font-mono text-white/40">Context: {model.contextWindow}</span>
                                {model.isPremium && (
                                  <span className="text-[8px] font-bold bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1 rounded">PREMIUM</span>
                                )}
                              </div>
                            </div>
                            <span className="text-[10px] text-white/40 leading-relaxed line-clamp-2">{model.description}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Model Parameters sliders */}
            <div className="border-t border-white/5 pt-4 space-y-4">
              {/* Temperature Slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider">Inference Entropy (Temp)</label>
                  <span className="text-xs font-mono font-bold text-indigo-300 bg-indigo-950/50 border border-indigo-900/30 px-1.5 py-0.5 rounded">
                    {modelConfig.temperature.toFixed(1)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="1.5"
                  step="0.1"
                  value={modelConfig.temperature}
                  onChange={(e) => setModelConfig({ ...modelConfig, temperature: parseFloat(e.target.value) })}
                  className="w-full accent-indigo-500 h-1 bg-black/40 rounded-lg cursor-pointer"
                />
                <p className="text-[10px] text-indigo-200/60 font-medium italic">
                  {getTemperatureDescriptor(modelConfig.temperature)}
                </p>
              </div>

              {/* Max Output Tokens Select */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Max Output Limit</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[512, 1024, 2048, 4096].map((tokens) => (
                    <button
                      key={tokens}
                      onClick={() => setModelConfig({ ...modelConfig, maxTokens: tokens })}
                      className={`py-1 px-1 text-center rounded-lg border text-xs font-semibold cursor-pointer transition-all ${
                        modelConfig.maxTokens === tokens
                          ? 'bg-indigo-600 text-white border-indigo-500'
                          : 'bg-white/5 border-white/5 text-white/40 hover:text-white/80 hover:border-white/10'
                      }`}
                    >
                      {tokens}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'billing' && (
          <div className="space-y-5 animate-fade-in text-xs">
            {isCheckoutOpen ? (
              /* --- Interactive Refill Checkout Flow Panel --- */
              <div className="p-4 rounded-2xl bg-gradient-to-b from-[#14141a] to-[#09090c] border border-indigo-500/30 shadow-2xl relative space-y-4 animate-fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Icons.ShieldCheck className="h-4 w-4 text-emerald-400" />
                    <span className="font-bold text-white uppercase tracking-wider text-[11px]">Secure Sandbox Checkout</span>
                  </div>
                  <button 
                    onClick={() => setIsCheckoutOpen(false)}
                    className="p-1 rounded-lg hover:bg-white/5 text-white/40 hover:text-white cursor-pointer"
                  >
                    <Icons.X className="h-3.5 w-3.5" />
                  </button>
                </div>

                {/* Amount Selector */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Select Top-Up Amount</span>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[10.00, 25.00, 50.00, 100.00].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setCheckoutAmount(amt)}
                        className={`py-2 rounded-xl border text-center font-bold font-mono transition-all cursor-pointer ${
                          checkoutAmount === amt
                            ? 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                            : 'bg-white/5 border-white/5 text-white/50 hover:bg-white/10 hover:border-white/10'
                        }`}
                      >
                        ${amt.toFixed(0)}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Source Account Selector */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Charged Account / Card</span>
                  {savedMethods.length === 0 ? (
                    <div className="p-3 bg-red-950/20 border border-red-500/15 rounded-xl text-red-300 text-[11px] space-y-2">
                      <p>You don't have any payment methods saved yet.</p>
                      <button
                        onClick={() => {
                          setIsCheckoutOpen(false);
                          setIsAddingMethod(true);
                        }}
                        className="text-[10px] font-bold text-indigo-400 hover:underline block"
                      >
                        + Add a payment method first
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-36 overflow-y-auto no-scrollbar">
                      {savedMethods.map((m) => {
                        const isSelected = selectedMethodId === m.id;
                        return (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setSelectedMethodId(m.id)}
                            className={`w-full text-left p-2.5 rounded-xl border flex items-center justify-between transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-indigo-950/30 border-indigo-500'
                                : 'bg-black/30 border-white/5 hover:bg-white/5'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className={`p-1 rounded bg-white/5 ${
                                m.type === 'paypal' ? 'text-sky-400' :
                                m.type === 'visa' ? 'text-indigo-400' :
                                m.type === 'mastercard' ? 'text-orange-400' : 'text-slate-300'
                              }`}>
                                {getMethodIcon(m.type)}
                              </span>
                              <div className="text-[11px]">
                                <span className="font-bold text-white block capitalize leading-none">
                                  {m.type === 'paypal' ? 'PayPal Account' : `${m.type} Card`}
                                </span>
                                <span className="text-[10px] text-white/40">
                                  {m.type === 'paypal' ? m.email : `•••• •••• •••• ${m.last4}`}
                                </span>
                              </div>
                            </div>
                            <div className={`h-4 w-4 rounded-full border flex items-center justify-center ${
                              isSelected ? 'border-indigo-500 bg-indigo-600' : 'border-white/10'
                            }`}>
                              {isSelected && <Icons.Check className="h-2.5 w-2.5 text-white" />}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Confirm Refill Action Button */}
                <div className="pt-2 space-y-2">
                  <button
                    onClick={handleConfirmRefill}
                    disabled={isProcessingCheckout || savedMethods.length === 0}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-indigo-950 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {isProcessingCheckout ? (
                      <>
                        <Icons.Loader2 className="h-4 w-4 animate-spin text-white" />
                        <span>Verifying Sandbox Auth...</span>
                      </>
                    ) : (
                      <>
                        <Icons.CheckCircle className="h-4 w-4 text-indigo-200" />
                        <span>Pay ${checkoutAmount.toFixed(2)} & Complete Refill</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    disabled={isProcessingCheckout}
                    className="w-full py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white/60 hover:text-white text-[11px] font-semibold transition-all cursor-pointer"
                  >
                    Cancel Checkout
                  </button>
                </div>
              </div>
            ) : (
              /* --- Default Wallet / Balance Card View --- */
              <div className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-purple-950/20 to-[#0d0d11] border border-white/10 shadow-xl relative overflow-hidden flex flex-col gap-3">
                <div className="absolute top-0 right-0 h-24 w-24 bg-indigo-500/10 rounded-full blur-2xl -mr-6 -mt-6"></div>
                
                <div className="flex justify-between items-center z-10">
                  <span className="text-[10px] font-bold font-mono text-indigo-300 uppercase tracking-widest">Cognitive Wallet</span>
                  <Icons.Coins className="h-4 w-4 text-indigo-400 animate-spin" style={{ animationDuration: '6s' }} />
                </div>
                
                <div className="z-10">
                  <span className="text-[10px] text-white/40 block uppercase tracking-wider">Available Balance</span>
                  <span className="text-3xl font-mono font-black text-white leading-none">
                    ${walletBalance.toFixed(6)}
                  </span>
                </div>

                <button
                  onClick={handleRefillWallet}
                  className="w-full mt-1.5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center justify-center gap-1.5 active:scale-95 border border-indigo-400/20"
                >
                  <Icons.Wallet className="h-3.5 w-3.5" />
                  <span>Refill +$10.00 Credits</span>
                </button>
              </div>
            )}

            {/* --- Manage Saved Payment Methods Section --- */}
            <div className="space-y-3.5">
              <div className="flex justify-between items-center">
                <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block font-mono">Saved Payment Methods</label>
                {!isCheckoutOpen && (
                  <button
                    onClick={() => setIsAddingMethod(!isAddingMethod)}
                    className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    {isAddingMethod ? 'Cancel' : '+ Add New'}
                  </button>
                )}
              </div>

              {/* Add Payment Method Form */}
              {isAddingMethod && (
                <form onSubmit={handleAddPaymentMethod} className="p-3.5 rounded-xl bg-white/[0.02] border border-white/10 space-y-3.5 animate-fade-in">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">Method Type</span>
                    <div className="grid grid-cols-3 gap-1">
                      {[
                        { id: 'visa', label: 'Visa', icon: Icons.CreditCard },
                        { id: 'mastercard', label: 'Mastercard', icon: Icons.CreditCard },
                        { id: 'amex', label: 'Amex', icon: Icons.CreditCard },
                        { id: 'paypal', label: 'PayPal', icon: Icons.Wallet },
                        { id: 'applepay', label: 'Apple Pay', icon: Icons.Smartphone },
                        { id: 'googlepay', label: 'Google Pay', icon: Icons.QrCode },
                      ].map((t) => (
                        <button
                          key={t.id}
                          type="button"
                          onClick={() => setNewMethodType(t.id as any)}
                          className={`py-1.5 px-1 rounded-lg border text-[10px] font-semibold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                            newMethodType === t.id
                              ? 'bg-indigo-600/25 border-indigo-500 text-white'
                              : 'bg-black/20 border-white/5 text-white/40 hover:text-white/70'
                          }`}
                        >
                          <span className={`${
                            newMethodType === t.id ? 'text-indigo-400' : 'text-white/20'
                          }`}>
                            {t.id === 'paypal' ? <Icons.Wallet className="h-3.5 w-3.5 text-sky-400" /> :
                             t.id === 'applepay' ? <Icons.Smartphone className="h-3.5 w-3.5 text-white" /> :
                             t.id === 'googlepay' ? <Icons.QrCode className="h-3.5 w-3.5 text-emerald-400" /> :
                             <Icons.CreditCard className="h-3.5 w-3.5" />}
                          </span>
                          <span>{t.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {newMethodType === 'paypal' ? (
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">PayPal Email Address</label>
                      <input
                        type="email"
                        required
                        value={paypalEmail}
                        onChange={(e) => setPaypalEmail(e.target.value)}
                        placeholder="your-email@paypal.com"
                        className="w-full text-xs rounded-lg border border-white/10 bg-black/40 p-2 text-white placeholder-white/20 focus:border-indigo-500 focus:outline-none"
                      />
                    </div>
                  ) : newMethodType === 'applepay' || newMethodType === 'googlepay' ? (
                    <div className="p-3 bg-indigo-950/10 border border-indigo-500/10 rounded-xl text-[10px] text-white/50 leading-relaxed">
                      💡 {newMethodType === 'applepay' ? 'Apple Pay' : 'Google Pay'} requires device biometric confirmation. Adding this sandbox profile will automatically link your sandbox device tokens.
                    </div>
                  ) : (
                    /* Credit Card Form Inputs */
                    <div className="space-y-2">
                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Cardholder Name</label>
                        <input
                          type="text"
                          required={newMethodType !== 'paypal'}
                          value={cardName}
                          onChange={(e) => setCardName(e.target.value)}
                          placeholder="e.g. Jionni Petty"
                          className="w-full text-xs rounded-lg border border-white/10 bg-black/40 p-2 text-white placeholder-white/20 focus:border-indigo-500 focus:outline-none"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Card Number</label>
                        <input
                          type="text"
                          required={newMethodType !== 'paypal'}
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value.replace(/\s?/g, '').replace(/(\d{4})/g, '$1 ').trim())}
                          placeholder="4111 2222 3333 4444"
                          maxLength={19}
                          className="w-full text-xs rounded-lg border border-white/10 bg-black/40 p-2 text-white placeholder-white/20 focus:border-indigo-500 focus:outline-none font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">Expiry (MM/YY)</label>
                          <input
                            type="text"
                            required={newMethodType !== 'paypal'}
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="12/29"
                            maxLength={5}
                            className="w-full text-xs rounded-lg border border-white/10 bg-black/40 p-2 text-white placeholder-white/20 focus:border-indigo-500 focus:outline-none font-mono text-center"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block">CVV</label>
                          <input
                            type="password"
                            required={newMethodType !== 'paypal'}
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                            placeholder="***"
                            maxLength={4}
                            className="w-full text-xs rounded-lg border border-white/10 bg-black/40 p-2 text-white placeholder-white/20 focus:border-indigo-500 focus:outline-none font-mono text-center"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 pt-1">
                    <button
                      type="submit"
                      className="flex-1 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs cursor-pointer text-center"
                    >
                      Save Method
                    </button>
                    <button
                      type="button"
                      onClick={() => setIsAddingMethod(false)}
                      className="flex-1 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white/60 font-semibold text-xs cursor-pointer text-center"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}

              {/* Saved Methods List */}
              <div className="space-y-1.5">
                {savedMethods.length === 0 ? (
                  <p className="text-center text-white/30 italic py-4">No payment methods linked.</p>
                ) : (
                  savedMethods.map((m) => {
                    return (
                      <div
                        key={m.id}
                        onClick={() => handleSetDefaultMethod(m.id)}
                        className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between group ${
                          m.isDefault
                            ? 'bg-indigo-950/15 border-indigo-500/40'
                            : 'bg-white/[0.01] border-white/5 hover:bg-white/5 hover:border-white/10'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className={`p-1.5 rounded-lg ${
                            m.type === 'paypal' ? 'bg-sky-500/10 text-sky-400' :
                            m.type === 'visa' ? 'bg-indigo-500/10 text-indigo-400' :
                            m.type === 'mastercard' ? 'bg-orange-500/10 text-orange-400' :
                            m.type === 'applepay' ? 'bg-white/5 text-white' : 'bg-emerald-500/10 text-emerald-400'
                          }`}>
                            {getMethodIcon(m.type)}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-white capitalize">
                                {m.type === 'paypal' ? 'PayPal Account' : `${m.type}`}
                              </span>
                              {m.isDefault && (
                                <span className="text-[8px] font-mono font-black text-indigo-400 uppercase tracking-widest bg-indigo-500/10 px-1 rounded border border-indigo-500/10">
                                  Default
                                </span>
                              )}
                            </div>
                            <p className="text-[10px] text-white/40 font-mono">
                              {m.type === 'paypal' ? m.email : `•••• •••• •••• ${m.last4}`}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          {!m.isDefault && (
                            <span className="text-[9px] text-indigo-400/50 group-hover:text-indigo-400 font-semibold opacity-0 group-hover:opacity-100 transition-all">
                              Set Default
                            </span>
                          )}
                          <button
                            type="button"
                            onClick={(e) => handleDeleteMethod(m.id, e)}
                            className="p-1 rounded text-white/20 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                            title="Delete Payment Method"
                          >
                            <Icons.Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Payment Tier Selector */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block font-mono">Payment Routing Tier</label>
              <div className="space-y-2">
                {[
                  {
                    id: 'credits',
                    title: 'Token Credits',
                    description: 'Direct per-token micro-deductions. Perfect for testing.',
                    icon: Icons.Coins
                  },
                  {
                    id: 'card',
                    title: 'Simulated Card',
                    description: 'Charges sandbox Visa/MC. Deducts $0.00 from credits.',
                    icon: Icons.CreditCard
                  },
                  {
                    id: 'subscription',
                    title: 'Unlimited Pass',
                    description: '$19.99/mo. Standard free, Premium models discounted.',
                    icon: Icons.Zap
                  }
                ].map((tier) => {
                  const isSelected = paymentMethod === tier.id;
                  const TierIcon = tier.icon;
                  return (
                    <button
                      key={tier.id}
                      onClick={() => {
                        setPaymentMethod(tier.id as any);
                        showToast(`SWITCHED BILLING ROUTE TO: ${tier.title.toUpperCase()}`);
                      }}
                      className={`w-full text-left p-3 rounded-xl border transition-all text-xs cursor-pointer flex items-start gap-2.5 ${
                        isSelected
                          ? 'bg-indigo-950/20 border-indigo-500 shadow-sm'
                          : 'bg-white/[0.01] border-white/5 hover:bg-white/5 hover:border-white/10'
                      }`}
                    >
                      <div className={`p-1.5 rounded-lg shrink-0 ${isSelected ? 'bg-indigo-600 text-white' : 'bg-white/5 text-white/40'}`}>
                        <TierIcon className="h-3.5 w-3.5" />
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white">{tier.title}</span>
                          {isSelected && <span className="h-1.5 w-1.5 rounded-full bg-indigo-400 animate-pulse" />}
                        </div>
                        <p className="text-[10px] text-white/40 leading-relaxed">{tier.description}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Billing Queue Priority */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-white/50 uppercase tracking-wider block font-mono">Routing Priority</label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'eco', label: 'Eco (-15%)', desc: 'Throttled speed' },
                  { id: 'standard', label: 'Standard', desc: 'Normal queue' },
                  { id: 'priority', label: 'Express (+25%)', desc: 'Priority queue' },
                ].map((item) => {
                  const isSelected = billingPriority === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        setBillingPriority(item.id as any);
                        showToast(`QUEUE ROUTING: ${item.id.toUpperCase()}`);
                      }}
                      className={`py-2 px-1 text-center rounded-xl border cursor-pointer transition-all flex flex-col items-center justify-center gap-0.5 ${
                        isSelected
                          ? 'bg-indigo-600 border-indigo-500 text-white'
                          : 'bg-white/5 border-white/5 text-white/40 hover:text-white/80 hover:border-white/10'
                      }`}
                    >
                      <span className="text-[10px] font-bold">{item.label}</span>
                      <span className="text-[8px] text-white/30 truncate leading-none">{item.desc}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Pricing Matrix table */}
            <div className="space-y-1.5 pt-1.5 border-t border-white/5">
              <span className="text-[10px] font-bold text-white/50 uppercase tracking-wider block font-mono">Cognitive Costs (per 1K Tokens)</span>
              <div className="border border-white/5 rounded-xl overflow-hidden bg-black/20 text-[10px]">
                <table className="w-full text-left border-collapse font-mono">
                  <thead>
                    <tr className="bg-white/5 text-white/40 text-[8px] uppercase tracking-wider">
                      <th className="p-2">Model Node</th>
                      <th className="p-2 text-right">Prompt</th>
                      <th className="p-2 text-right">Output</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-white/60">
                    {AI_MODELS.map(m => {
                      return (
                        <tr key={m.id} className="hover:bg-white/[0.02]">
                          <td className="p-2 font-sans font-semibold text-white truncate max-w-[120px]" title={m.name}>{m.name}</td>
                          <td className="p-2 text-right">${m.inputCostPer1K.toFixed(5)}</td>
                          <td className="p-2 text-right">${m.outputCostPer1K.toFixed(5)}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
