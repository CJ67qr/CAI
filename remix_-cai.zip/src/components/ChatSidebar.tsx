import React, { useState } from 'react';
import { Plus, MessageSquare, Trash2, Edit2, Check, X, Search, Moon, Trash } from 'lucide-react';
import { ChatSession } from '../types';

interface ChatSidebarProps {
  sessions: ChatSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onClearAllSessions: () => void;
  userEmail?: string;
  isOpen?: boolean;
  onClose?: () => void;
}

export default function ChatSidebar({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession,
  onRenameSession,
  onClearAllSessions,
  userEmail = 'cai.user@ai.studio',
  isOpen = false,
  onClose,
}: ChatSidebarProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');

  const startRename = (id: string, currentTitle: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(id);
    setEditingTitle(currentTitle);
  };

  const saveRename = (id: string, e: React.MouseEvent | React.KeyboardEvent) => {
    e.stopPropagation();
    if (editingTitle.trim()) {
      onRenameSession(id, editingTitle.trim());
    }
    setEditingId(null);
  };

  const cancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  // Grouping logic based on session timestamps
  const groupSessions = (sessionsList: ChatSession[]) => {
    const today: ChatSession[] = [];
    const yesterday: ChatSession[] = [];
    const previousWeek: ChatSession[] = [];
    const older: ChatSession[] = [];

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const sevenDays = 7 * oneDay;

    sessionsList.forEach((session) => {
      // Lowercase filter check
      if (searchTerm && !session.title.toLowerCase().includes(searchTerm.toLowerCase())) {
        return;
      }

      const diff = now - session.updatedAt;
      if (diff < oneDay) {
        today.push(session);
      } else if (diff < 2 * oneDay) {
        yesterday.push(session);
      } else if (diff < sevenDays) {
        previousWeek.push(session);
      } else {
        older.push(session);
      }
    });

    return { today, yesterday, previousWeek, older };
  };

  const { today, yesterday, previousWeek, older } = groupSessions(sessions);

  const renderGroup = (title: string, group: ChatSession[]) => {
    if (group.length === 0) return null;

    return (
      <div className="space-y-1 pt-4 first:pt-0 animate-fade-in">
        <h3 className="px-3 text-[10px] font-bold text-obsidian-450 uppercase tracking-wider">{title}</h3>
        <div className="space-y-0.5">
          {group.map((session) => {
            const isActive = session.id === activeSessionId;
            const isEditing = session.id === editingId;

            return (
              <div
                key={session.id}
                onClick={() => !isEditing && onSelectSession(session.id)}
                className={`group relative flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-xs font-medium cursor-pointer transition-all ${
                  isActive
                    ? 'bg-amethyst-950/50 border border-amethyst-900/30 text-white'
                    : 'border border-transparent text-obsidian-300 hover:bg-obsidian-900/50 hover:text-white'
                }`}
              >
                <MessageSquare className={`h-4 w-4 shrink-0 ${isActive ? 'text-amethyst-400' : 'text-obsidian-500 group-hover:text-obsidian-300'}`} />
                
                {isEditing ? (
                  <input
                    type="text"
                    value={editingTitle}
                    onChange={(e) => setEditingTitle(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && saveRename(session.id, e)}
                    className="flex-1 bg-obsidian-950/80 text-white px-1.5 py-0.5 text-xs rounded border border-amethyst-500 focus:outline-none focus:ring-1 focus:ring-amethyst-500"
                    autoFocus
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <span className="flex-1 truncate pr-8 leading-snug">{session.title}</span>
                )}

                {/* Edit & Delete Actions */}
                {!isEditing && (
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 flex items-center gap-1 bg-gradient-to-l from-obsidian-900 group-hover:from-obsidian-900/90 pl-3">
                    <button
                      onClick={(e) => startRename(session.id, session.title, e)}
                      className="p-1 hover:text-amethyst-300 text-obsidian-450 rounded hover:bg-obsidian-800 transition-colors"
                      title="Rename Conversation"
                    >
                      <Edit2 className="h-3 w-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSession(session.id);
                      }}
                      className="p-1 hover:text-red-400 text-obsidian-450 rounded hover:bg-obsidian-800 transition-colors"
                      title="Delete Conversation"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                )}

                {isEditing && (
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    <button
                      onClick={(e) => saveRename(session.id, e)}
                      className="p-0.5 hover:bg-obsidian-800 text-emerald-400 rounded"
                    >
                      <Check className="h-3 w-3" />
                    </button>
                    <button
                      onClick={cancelRename}
                      className="p-0.5 hover:bg-obsidian-800 text-red-400 rounded"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className={`flex h-full w-64 flex-col bg-obsidian-950 border-r border-obsidian-850 shrink-0 transition-transform duration-300 ease-in-out
      fixed inset-y-0 left-0 z-40 lg:static lg:translate-x-0
      ${isOpen ? 'translate-x-0' : '-translate-x-full'}
    `}>
      {/* Sidebar Header with CAI Logo */}
      <div className="p-4 border-b border-obsidian-850">
        <div className="flex items-center justify-between px-1 mb-3 gap-2">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-lg bg-gradient-to-tr from-amethyst-500 to-amethyst-700 flex items-center justify-center shadow-md">
              <span className="text-white font-extrabold text-xs tracking-wider">CAI</span>
            </div>
            <div>
              <span className="text-sm font-extrabold text-white tracking-tight">CAI Portal</span>
              <span className="text-[9px] text-amethyst-400 font-semibold block uppercase leading-none mt-0.5">Cognitive Assistant</span>
            </div>
          </div>
          {onClose && (
            <button
              onClick={onClose}
              className="lg:hidden p-1.5 rounded-lg text-obsidian-450 hover:text-white hover:bg-obsidian-800 transition-colors cursor-pointer"
              title="Close Sidebar"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* New Chat Button */}
        <button
          onClick={onNewChat}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-amethyst-600 to-amethyst-700 hover:from-amethyst-500 hover:to-amethyst-600 text-white text-xs font-semibold shadow-md active:scale-[0.98] transition-all cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          <span>New Chat</span>
        </button>
      </div>

      {/* Search Sessions Bar */}
      <div className="px-3 pt-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-obsidian-500" />
          <input
            type="text"
            placeholder="Search conversations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs rounded-xl border border-obsidian-850 bg-obsidian-900/40 py-2 pl-9 pr-3 text-obsidian-200 placeholder-obsidian-550 focus:border-amethyst-500/50 focus:outline-none focus:ring-1 focus:ring-amethyst-500/30"
          />
        </div>
      </div>

      {/* Sessions list */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-4 no-scrollbar">
        {sessions.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-center px-4">
            <MessageSquare className="h-6 w-6 text-obsidian-750 mb-2" />
            <p className="text-xs text-obsidian-450">No chats yet.</p>
            <p className="text-[10px] text-obsidian-500 mt-1">Start a conversation with CAI.</p>
          </div>
        ) : (
          <>
            {renderGroup('Today', today)}
            {renderGroup('Yesterday', yesterday)}
            {renderGroup('Previous 7 Days', previousWeek)}
            {renderGroup('Older', older)}
          </>
        )}
      </div>

      {/* Bottom Profile / Utility Block */}
      <div className="p-3 border-t border-obsidian-850 bg-obsidian-950/60 space-y-2">
        {sessions.length > 0 && (
          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear all chat histories? This cannot be undone.')) {
                onClearAllSessions();
              }
            }}
            className="w-full flex items-center gap-2 px-3 py-2 text-[11px] font-semibold text-red-400 hover:text-red-300 hover:bg-red-950/20 rounded-lg transition-colors cursor-pointer"
          >
            <Trash className="h-3.5 w-3.5 shrink-0" />
            <span>Clear Conversation Logs</span>
          </button>
        )}

        {/* Profile Card */}
        <div className="flex items-center gap-2.5 px-3 py-2 bg-obsidian-900/40 rounded-xl border border-obsidian-850">
          <div className="h-7 w-7 rounded-full bg-amethyst-900 border border-amethyst-600/30 flex items-center justify-center text-xs font-bold text-amethyst-200 uppercase">
            {userEmail.substring(0, 2)}
          </div>
          <div className="flex-1 min-w-0">
            <span className="text-[11px] font-semibold text-white truncate block">{userEmail}</span>
            <span className="text-[9px] text-obsidian-450 block font-medium leading-none mt-0.5">Developer Environment</span>
          </div>
        </div>
      </div>
    </div>
  );
}
