import React, { useState } from 'react';
import { Copy, Check, Terminal, Code2 } from 'lucide-react';

interface MarkdownRendererProps {
  content: string;
}

export default function MarkdownRenderer({ content }: MarkdownRendererProps) {
  if (!content) return null;

  // Split content by code blocks: ```lang\ncode\n```
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-3 leading-relaxed text-sm text-obsidian-100 select-text">
      {parts.map((part, index) => {
        if (part.startsWith('```')) {
          // This is a code block
          const match = part.match(/```(\w*)\n([\s\S]*?)```/);
          const language = match ? match[1] : 'code';
          const code = match ? match[2] : part.replace(/```/g, '');
          return <CodeBlock key={index} code={code.trim()} language={language} />;
        } else {
          // This is standard text (might contain headings, inline code, bold, lists, tables, etc.)
          return <TextBlock key={index} text={part} />;
        }
      })}
    </div>
  );
}

// 1. Code Block Component with Copy to Clipboard functionality
function CodeBlock({ code, language, key }: { code: string; language: string; key?: React.Key }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy code: ', err);
    }
  };

  return (
    <div className="my-4 overflow-hidden rounded-xl border border-obsidian-800 bg-obsidian-950 shadow-lg">
      {/* Header bar */}
      <div className="flex items-center justify-between bg-obsidian-900 px-4 py-2 text-xs font-mono text-obsidian-400 border-b border-obsidian-800">
        <div className="flex items-center gap-1.5">
          <Terminal className="h-3.5 w-3.5 text-amethyst-400" />
          <span className="uppercase tracking-wider font-semibold text-amethyst-300">{language || 'code'}</span>
        </div>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1 rounded bg-obsidian-800/80 hover:bg-obsidian-800 px-2 py-1 text-obsidian-300 hover:text-white transition-colors duration-150 active:scale-95 cursor-pointer"
          title="Copy code"
        >
          {copied ? (
            <>
              <Check className="h-3 w-3 text-emerald-400 animate-scale-in" />
              <span className="text-emerald-400 font-medium">Copied!</span>
            </>
          ) : (
            <>
              <Copy className="h-3 w-3" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>
      {/* Preformatted code area */}
      <div className="overflow-x-auto p-4 font-mono text-xs text-amethyst-50/90 selection:bg-amethyst-800 select-text bg-obsidian-900/40">
        <pre><code>{code}</code></pre>
      </div>
    </div>
  );
}

// 2. Text Block Parser for inline elements and block layouts (lists, tables, quotes, headings)
function TextBlock({ text, key }: { text: string; key?: React.Key }) {
  // We can split the block by lines to parse structure
  const lines = text.split('\n');
  const renderedElements: React.ReactNode[] = [];
  
  let currentList: React.ReactNode[] = [];
  let currentListType: 'bullet' | 'number' | null = null;
  let currentTable: { headers: string[]; rows: string[][] } | null = null;

  const flushList = (key: string | number) => {
    if (currentList.length > 0) {
      if (currentListType === 'bullet') {
        renderedElements.push(
          <ul key={`ul-${key}`} className="list-disc list-inside pl-4 my-2.5 space-y-1 text-obsidian-200">
            {...currentList}
          </ul>
        );
      } else {
        renderedElements.push(
          <ol key={`ol-${key}`} className="list-decimal list-inside pl-4 my-2.5 space-y-1 text-obsidian-200">
            {...currentList}
          </ol>
        );
      }
      currentList = [];
      currentListType = null;
    }
  };

  const flushTable = (key: string | number) => {
    if (currentTable) {
      renderedElements.push(
        <div key={`table-${key}`} className="my-4 overflow-x-auto rounded-lg border border-obsidian-800 shadow-sm">
          <table className="min-w-full divide-y divide-obsidian-800 text-xs">
            <thead className="bg-obsidian-900 text-obsidian-300">
              <tr>
                {currentTable.headers.map((header, i) => (
                  <th key={i} className="px-4 py-2.5 text-left font-semibold tracking-wider border-r border-obsidian-800 last:border-r-0">
                    {header.trim()}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-obsidian-800 bg-obsidian-900/20 text-obsidian-200">
              {currentTable.rows.map((row, rowIndex) => (
                <tr key={rowIndex} className="hover:bg-obsidian-900/40 transition-colors">
                  {row.map((cell, cellIndex) => (
                    <td key={cellIndex} className="px-4 py-2 border-r border-obsidian-800 last:border-r-0 font-normal">
                      {parseInline(cell.trim())}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      currentTable = null;
    }
  };

  for (let idx = 0; idx < lines.length; idx++) {
    const line = lines[idx];
    const trimmed = line.trim();

    // 1. Skip completely empty lines, but flush any open lists/tables
    if (trimmed === '') {
      flushList(idx);
      flushTable(idx);
      continue;
    }

    // 2. Detect Table Divider row (e.g. |---|---|)
    if (trimmed.startsWith('|') && trimmed.includes('-') && idx > 0 && lines[idx - 1].trim().startsWith('|')) {
      // It's a table alignment divider, skip rendering, but verify table setup
      continue;
    }

    // 3. Detect Table Row (starts and ends with |)
    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      flushList(idx);
      const cells = trimmed.split('|').slice(1, -1); // split and remove empty outer segments
      
      if (!currentTable) {
        // First row of table is treated as headers
        currentTable = {
          headers: cells,
          rows: []
        };
      } else {
        currentTable.rows.push(cells);
      }
      continue;
    } else {
      // If we see a non-table line, flush any active table
      flushTable(idx);
    }

    // 4. Detect Headings
    if (trimmed.startsWith('#')) {
      flushList(idx);
      const headingMatch = trimmed.match(/^(#{1,6})\s+(.*)$/);
      if (headingMatch) {
        const level = headingMatch[1].length;
        const content = headingMatch[2];
        const headingStyles = [
          'text-2xl font-bold tracking-tight text-white pt-4 pb-1 border-b border-obsidian-800', // h1
          'text-xl font-bold tracking-tight text-white pt-3 pb-0.5', // h2
          'text-lg font-semibold tracking-tight text-amethyst-200 pt-2', // h3
          'text-base font-semibold text-amethyst-300 pt-1.5', // h4
          'text-sm font-semibold text-amethyst-400', // h5
          'text-xs font-semibold uppercase tracking-wider text-amethyst-400' // h6
        ];
        renderedElements.push(
          React.createElement(
            `h${level}`,
            { key: idx, className: headingStyles[level - 1] || 'font-bold' },
            parseInline(content)
          )
        );
        continue;
      }
    }

    // 5. Detect Blockquote
    if (trimmed.startsWith('>')) {
      flushList(idx);
      const content = trimmed.substring(1).trim();
      renderedElements.push(
        <blockquote key={idx} className="my-2 border-l-4 border-amethyst-500 bg-obsidian-900/60 px-4 py-2.5 rounded-r-lg text-obsidian-300 italic">
          {parseInline(content)}
        </blockquote>
      );
      continue;
    }

    // 6. Detect Bullet list item
    if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
      if (currentListType !== 'bullet') {
        flushList(idx);
        currentListType = 'bullet';
      }
      currentList.push(
        <li key={`li-${idx}`} className="list-item pl-1">
          {parseInline(trimmed.substring(2))}
        </li>
      );
      continue;
    }

    // 7. Detect Numbered list item
    const numberMatch = trimmed.match(/^(\d+)\.\s+(.*)$/);
    if (numberMatch) {
      if (currentListType !== 'number') {
        flushList(idx);
        currentListType = 'number';
      }
      currentList.push(
        <li key={`li-${idx}`} className="list-item pl-1">
          {parseInline(numberMatch[2])}
        </li>
      );
      continue;
    }

    // 8. Horizontal Rule
    if (trimmed === '---') {
      flushList(idx);
      renderedElements.push(<hr key={idx} className="my-4 border-obsidian-800" />);
      continue;
    }

    // 9. Standard paragraph line
    flushList(idx);
    renderedElements.push(
      <p key={idx} className="mb-2 text-obsidian-100 last:mb-0">
        {parseInline(line)}
      </p>
    );
  }

  // Final flushes
  flushList('final');
  flushTable('final');

  return <div className="space-y-1.5">{renderedElements}</div>;
}

// 3. Inline Parser for Bold, Italic, and Inline Code
function parseInline(text: string): React.ReactNode[] {
  // Parse `code`, **bold**, *italic*
  const parts = text.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);
  
  return parts.map((part, index) => {
    if (part.startsWith('`') && part.endsWith('`')) {
      // Inline Code
      return (
        <code key={index} className="mx-1 px-1.5 py-0.5 rounded bg-obsidian-800 border border-obsidian-750 font-mono text-xs text-amethyst-300 select-text">
          {part.substring(1, part.length - 1)}
        </code>
      );
    } else if (part.startsWith('**') && part.endsWith('**')) {
      // Bold
      return (
        <strong key={index} className="font-semibold text-white">
          {part.substring(2, part.length - 2)}
        </strong>
      );
    } else if (part.startsWith('*') && part.endsWith('*')) {
      // Italic
      return (
        <em key={index} className="italic text-obsidian-300">
          {part.substring(1, part.length - 1)}
        </em>
      );
    }
    return part;
  });
}
